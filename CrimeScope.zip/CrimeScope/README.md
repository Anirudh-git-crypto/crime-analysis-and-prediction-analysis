# 🔎 CrimeScope – Crime Analysis & Prediction Platform

An interactive Python dashboard that turns historical crime records into descriptive insights and a
clearly labelled statistical forecast of **aggregate** monthly counts. Built with Pandas, Scikit-learn,
Plotly, Seaborn, Matplotlib and Streamlit.

> **Project status (please read):** the full codebase, cleaning pipeline, analysis, forecasting module
> and 30 unit tests are in this repository. The dataset is large and is **not** committed, so the
> real-data results, figures and dashboard screenshots are generated when you run the pipeline below.
> Nothing in this README is a made-up statistic; sections that depend on running the data say so.

## Problem statement
Raw incident logs are hard to act on. CrimeScope answers questions such as: which categories are rising
or falling, where are recorded incidents concentrated, how do they vary by month, season and hour, and
what do simple models suggest about aggregate trends?

## Objectives
- Build a reusable, validated data-cleaning pipeline
- Provide descriptive analysis with correct handling of partial years and zero denominators
- Forecast aggregate monthly counts with a chronological split, a baseline and honest metrics
- Present everything in a clear, multi-page Streamlit dashboard

## Features
- **Cleaning pipeline** with a machine-readable report and hard validation checks
- **Overview** KPIs: total incidents, top category, top district, year-over-year change
- **Crime Analysis**: top-10 categories, category trends, month/season patterns, category comparison across years, weekday × hour heatmap
- **Location Analysis**: district / community-area comparison and a density map (when coordinates exist)
- **Crime Prediction**: seasonal-naive baseline vs Ridge and Gradient Boosting, MAE/RMSE/MAPE, actual vs predicted chart, limitations
- **Data Explorer**: filter by year, category and district; download CSV
- Loading, empty-filter and missing-data states; light/dark theme via Streamlit settings

## Tech stack
Python · Pandas · NumPy · Scikit-learn · Plotly · Matplotlib · Seaborn · Streamlit · Pytest · Git/GitHub

## Architecture
```mermaid
flowchart LR
    A[City of Chicago Data Portal] -->|scripts/download_data.py| B[data/raw CSV]
    B -->|src/data_cleaning.py| C[data/processed/crimes_clean.csv]
    C --> D[src/data_analysis.py]
    C --> E[src/prediction.py]
    D --> F[src/visualization.py]
    E --> F
    F --> G[Streamlit app.py + pages/]
    D --> H[scripts/generate_report.py]
    E --> H
    H --> I[assets/figures + results/key_insights.md]
```

```
CrimeScope/
├── app.py                  # landing page
├── pages/                  # 1_Overview … 5_Data_Explorer
├── src/                    # data_cleaning, data_analysis, prediction, visualization, ui, utils
├── scripts/                # download_data.py, generate_report.py
├── tests/                  # cleaning, analysis and forecasting tests
├── notebooks/crime_analysis.ipynb
├── data/README.md          # how to obtain the data
└── requirements.txt
```

## Dataset
City of Chicago **"Crimes – 2001 to Present"** (id `ijzp-q8t2`) from the
[City of Chicago Data Portal](https://data.cityofchicago.org/Public-Safety/Crimes-2001-to-Present/ijzp-q8t2),
sourced from the Chicago Police Department. Locations are at block level. Review the portal's terms of use
before reuse; the data is not redistributed here. See [`data/README.md`](data/README.md).

## Data preprocessing
Column standardisation, date parsing, dropping missing/impossible dates, de-duplication by `id`, category
normalisation (e.g. merging alias labels), coordinate validation against Chicago's bounding box,
type casting, derived time features, extreme-day reporting (3×IQR, flagged not removed) and final
validation. The full table is in [`data/README.md`](data/README.md).

## Exploratory data analysis
Implemented in `src/data_analysis.py` and walked through in `notebooks/crime_analysis.ipynb`. Year-over-year
change is only computed between two **complete, consecutive** years, and percentage changes return `NaN`
instead of dividing by zero.

## Machine learning methodology
- Target: monthly incident count (all crime, or one category)
- Split: strictly chronological – the last N months (default 12) are held out
- Models: **seasonal-naive baseline**, **Ridge** and **Gradient Boosting** on lag-1/2/3/12, month sin/cos and a time index
- No leakage: test forecasts are *recursive* (predictions are fed back as lags), and a unit test proves that changing test-period actuals does not change test predictions
- Metrics: MAE, RMSE, MAPE (zero actuals skipped), plus improvement over the baseline
- If a model cannot beat the baseline, the dashboard says so and uses the baseline for projections
- Scope: aggregate counts only – no individuals, suspects or addresses

## Model evaluation results
Produced by `python scripts/generate_report.py` → `results/forecast_metrics.csv` and
`results/key_insights.md`. They depend on the date range you download, so no figures are quoted here.

## Key Insights Discovered
Generated from the actual data into `results/key_insights.md` when you run `scripts/generate_report.py`
(most common category, top district, year-over-year change, peak month and season, largest category
increases/decreases, forecast metrics). After running it on the real dataset, paste the output here.

## Dashboard screenshots
Pending: run the app (below) and save screenshots to `assets/`, e.g. `assets/dashboard_preview.png`.

## Installation
```bash
git clone https://github.com/Anirudh-git-crypto/CrimeScope-Crime-Analysis-Prediction.git
cd CrimeScope-Crime-Analysis-Prediction
python -m venv .venv && source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

## How to run
```bash
python scripts/download_data.py --start-year 2018 --end-year 2024
python -m src.data_cleaning --input data/raw/chicago_crimes.csv --output data/processed/crimes_clean.csv
python scripts/generate_report.py      # optional: figures + key insights
streamlit run app.py
pytest                                  # run the tests
```

## Technical Challenges & Solutions
| Challenge | Solution |
|---|---|
| The latest year (and sometimes first/last month) is incomplete, so naive year-over-year comparisons mislead | Track months covered per year, compute YoY only between complete consecutive years, drop incomplete edge months before forecasting |
| Percentage change with a zero baseline | `safe_pct_change` returns `NaN`; categories with no baseline are labelled "New (no baseline)" |
| Preventing leakage in time-series evaluation | Chronological split, recursive test forecasts, and a unit test that perturbs test actuals |
| Bad coordinates (zeros, outside the city) distort maps | Validate against a bounding box and null the pair while keeping the incident |
| Dataset too large for GitHub | Download script + git-ignored data folders + documented steps |
| Models may not beat a strong seasonal baseline | Report honestly, keep the baseline as a contender, and fall back to it automatically |

## Limitations
Recorded crime reflects reporting and policing practices; counts are not population-adjusted; block-level
locations; forecasts ignore policy changes and shocks; a single hold-out period gives noisy metrics. The
dashboard pages were written against the Streamlit/Plotly APIs but could not be executed in the authoring
environment (no package installs), so run them locally and open an issue if anything misbehaves.

## Future improvements
Population-normalised rates, community-area names and choropleths, prediction intervals, rolling-origin
cross-validation, Prophet/SARIMA comparison, CI with GitHub Actions, deployment to Streamlit Community Cloud.

## Author
**Anirudh-git-crypto** – aspiring Data Analyst / Python Developer · [GitHub](https://github.com/Anirudh-git-crypto)
