"""CrimeScope landing page. Run with: streamlit run app.py"""
import streamlit as st

from src import ui
from src.utils import clean_data_path

ui.setup_page("Home", "🔎")

st.title("🔎 CrimeScope")
st.subheader("Crime analysis & aggregate trend forecasting")
st.write(
    "An interactive dashboard that turns historical crime records into descriptive insights "
    "and a clearly labelled statistical forecast of **aggregate** monthly counts. "
    "Use the sidebar to open a page."
)

df = ui.require_data()
c1, c2, c3, c4 = st.columns(4)
with c1:
    ui.kpi_card("Records loaded", f"{len(df):,}")
with c2:
    ui.kpi_card("First record", df["date"].min().strftime("%Y-%m-%d"))
with c3:
    ui.kpi_card("Last record", df["date"].max().strftime("%Y-%m-%d"))
with c4:
    ui.kpi_card("Categories", f"{df['primary_type'].nunique()}")

st.markdown(
    """
**Pages**
- **Overview** – headline KPIs and yearly totals
- **Crime Analysis** – categories, trends, months, seasons and time of day
- **Location Analysis** – districts, community areas and a density map
- **Crime Prediction** – baseline vs. model forecast with honest evaluation
- **Data Explorer** – filter the data and download it as CSV

**Reading this dashboard:** figures are *historical recorded incidents*; the Prediction page shows
*model projections*, not real future events. Recorded crime also reflects reporting and policing practices.
Switch light/dark theme from Streamlit's **Settings** menu (top right).
"""
)
st.caption(f"Data file: `{clean_data_path().name}` · Source: City of Chicago Data Portal (see README).")
