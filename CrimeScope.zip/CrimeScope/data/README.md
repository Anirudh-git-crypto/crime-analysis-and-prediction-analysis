# Data

CrimeScope uses the **City of Chicago "Crimes - 2001 to Present"** dataset, published on the
[City of Chicago Data Portal](https://data.cityofchicago.org/Public-Safety/Crimes-2001-to-Present/ijzp-q8t2)
(dataset id `ijzp-q8t2`). Records are reported incidents from the Chicago Police Department's
CLEAR system, with personally identifying details removed and locations given at block level.
Please read the portal's terms of use and dataset notes before reuse; this repository does not
redistribute the data.

The full file is over 1 GB, so it is **not** committed. Download a subset instead:

```bash
python scripts/download_data.py --start-year 2018 --end-year 2024     # -> data/raw/chicago_crimes.csv
python -m src.data_cleaning --input data/raw/chicago_crimes.csv \
                            --output data/processed/crimes_clean.csv
python scripts/generate_report.py                                       # figures + key insights
streamlit run app.py
```

Alternatively, use the portal's **Export → CSV** button (filter `Year` first) and save the file as
`data/raw/chicago_crimes.csv`.

Both `data/raw/` and `data/processed/` are git-ignored. Set `CRIMESCOPE_DATA` to point the app at a
cleaned file stored elsewhere.

## Cleaning steps (see `src/data_cleaning.py`)

| Step | Why |
|---|---|
| Standardise column names to snake_case | Consistent access (`Primary Type` → `primary_type`) |
| Keep only analysis columns | Smaller file, faster app |
| Parse `date` with the portal's format, fall back to generic parsing | Reliable datetimes; unparseable values become missing |
| Drop rows with missing date or category | Cannot be placed in time or in a category |
| Drop dates before 2001 or in the future | Impossible values |
| Remove duplicates (by `id`, then whole row) | Avoid double counting |
| Normalise category labels, merge known aliases | e.g. `CRIM SEXUAL ASSAULT` → `CRIMINAL SEXUAL ASSAULT` |
| Null out coordinates outside Chicago or equal to 0 | Prevents map distortion; row is kept |
| Cast booleans and numeric columns | Correct types |
| Add year, month, hour, weekday, season, month-start | Needed for trend analysis |
| Report extreme days (3×IQR on daily counts) | Flagged but kept; may be real events |
| Validate (no missing keys, unique ids, coordinates in bounds, year matches date) | Fails loudly if the output is inconsistent |
