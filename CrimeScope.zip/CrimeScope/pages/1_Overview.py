import streamlit as st

from src import ui
from src.data_analysis import headline_kpis, yearly_growth
from src.utils import format_int, format_pct
from src.visualization import yearly_trend

ui.setup_page("Overview", "📊")
st.title("📊 Overview")

df = ui.sidebar_filters(ui.require_data())
kpis = headline_kpis(df)

c1, c2, c3, c4 = st.columns(4)
with c1:
    ui.kpi_card("Total incidents", format_int(kpis["total"]))
with c2:
    ui.kpi_card("Most common category", str(kpis["top_category"]).title(),
                f"{format_int(kpis['top_category_count'])} incidents")
with c3:
    district = f"District {kpis['top_district']}" if kpis["top_district"] is not None else "n/a"
    ui.kpi_card("Highest-count district", district)
with c4:
    if kpis["yoy_years"]:
        pct = kpis["yoy_pct"]
        a, b = kpis["yoy_years"]
        ui.kpi_card(f"Change {a} → {b}", format_pct(pct), "vs. previous complete year",
                    "up" if pct > 0 else "down")
    else:
        ui.kpi_card("Year-over-year change", "n/a", "needs two consecutive complete years")

st.markdown("### Yearly crime overview")
growth = yearly_growth(df)
st.plotly_chart(yearly_trend(growth), use_container_width=True)
ui.explain("Recorded incidents per year. Grey bars are partial years (fewer than 12 months of data) "
           "and are excluded from year-over-year comparisons.")

with st.expander("Year-over-year table"):
    table = growth.rename(columns={"pct_change": "YoY change (%)"})
    st.dataframe(table.round({"YoY change (%)": 2}), use_container_width=True, hide_index=True)
