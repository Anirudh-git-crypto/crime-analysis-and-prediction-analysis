import streamlit as st

from src import ui
from src.data_analysis import (category_change, category_counts, category_year_matrix,
                               hour_weekday_matrix, monthly_distribution, seasonal_counts)
from src.visualization import (bar_categories, category_change_bar, category_lines,
                               category_year_heatmap, hour_weekday_heatmap, monthly_bar,
                               seasonal_bar)

ui.setup_page("Crime Analysis", "🧭")
st.title("🧭 Crime Analysis")

df = ui.sidebar_filters(ui.require_data(), with_category=False)

st.markdown("### Top 10 crime categories")
top = category_counts(df, top_n=10)
st.plotly_chart(bar_categories(top, "Top 10 most reported categories"), use_container_width=True)
ui.explain("The ten most frequently recorded categories in the selected period.")

st.markdown("### Yearly trend by category")
default = list(top["category"].head(3))
chosen = st.multiselect("Categories to plot", list(category_counts(df)["category"]), default=default)
if chosen:
    st.plotly_chart(category_lines(df, chosen), use_container_width=True)
    ui.explain("Incidents per year for each selected category. The latest year may be partial.")
else:
    st.info("Select at least one category to see its trend.")

st.markdown("### Monthly and seasonal patterns")
left, right = st.columns(2)
with left:
    st.plotly_chart(monthly_bar(monthly_distribution(df)), use_container_width=True)
with right:
    st.plotly_chart(seasonal_bar(seasonal_counts(df)), use_container_width=True)
ui.explain("Totals by calendar month and season (Northern Hemisphere), using complete years only so "
           "partial years do not skew the comparison.")

st.markdown("### Category comparison across years")
years = sorted(int(y) for y in df["year"].unique())
if len(years) >= 2:
    c1, c2 = st.columns(2)
    start = c1.selectbox("From year", years, index=0)
    end = c2.selectbox("To year", years, index=len(years) - 1)
    if start == end:
        st.info("Choose two different years to compare.")
    else:
        change = category_change(df, start, end, top_n=15)
        st.plotly_chart(category_change_bar(change, f"% change by category, {start} → {end}"),
                        use_container_width=True)
        ui.explain("Percentage change in recorded incidents for the 15 largest categories. Categories with "
                   "no incidents in the starting year have no percentage and are omitted from the chart. "
                   "Partial years can understate or overstate the change.")
        with st.expander("Comparison table"):
            st.dataframe(change.round({"pct_change": 2}), use_container_width=True, hide_index=True)
else:
    st.info("At least two years of data are needed for a comparison.")

st.plotly_chart(category_year_heatmap(category_year_matrix(df, 10)), use_container_width=True)
ui.explain("Darker cells = more incidents. Compares the top 10 categories across all years at a glance.")

st.markdown("### Time of day")
st.plotly_chart(hour_weekday_heatmap(hour_weekday_matrix(df)), use_container_width=True)
ui.explain("When incidents are recorded, by weekday and hour. Timestamps reflect when the incident "
           "occurred as recorded, which is sometimes rounded (e.g. to midnight or noon).")
