import streamlit as st

from src import ui
from src.data_analysis import location_points, region_counts
from src.visualization import crime_density_map, region_bar

ui.setup_page("Location Analysis", "📍")
st.title("📍 Location Analysis")

df = ui.sidebar_filters(ui.require_data())

options = [c for c in ("district", "community_area") if c in df.columns and df[c].notna().any()]
if not options:
    st.warning("The dataset has no district or community-area information.")
    st.stop()

by = st.radio("Compare by", options, horizontal=True,
              format_func=lambda c: c.replace("_", " ").title())
top_n = st.slider("Number of regions to show", 5, 40, 20)
regions = region_counts(df, by, top_n=top_n)

st.markdown(f"### Incidents by {by.replace('_', ' ')}")
st.plotly_chart(region_bar(regions, by, f"Top {len(regions)} by recorded incidents"), use_container_width=True)
ui.explain("Raw counts of recorded incidents. Counts are not adjusted for population, so larger or "
           "busier areas naturally record more. They indicate concentration, not risk to any resident.")

with st.expander("Region table"):
    st.dataframe(regions.round({"share_pct": 2}), use_container_width=True, hide_index=True)

st.markdown("### Geographic density")
points = location_points(df)
if points.empty:
    st.info("No valid coordinates are available for the current selection.")
else:
    st.plotly_chart(crime_density_map(points), use_container_width=True)
    coverage = df[["latitude", "longitude"]].notna().all(axis=1).mean() * 100
    ui.explain(f"Heatmap of up to 50,000 randomly sampled incidents with valid coordinates "
               f"({coverage:.1f}% of the selected incidents have usable coordinates). "
               "Chicago publishes locations at block level, not exact addresses.")
