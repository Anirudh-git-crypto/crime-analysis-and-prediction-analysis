import streamlit as st

from src import ui
from src.data_analysis import category_counts
from src.prediction import LIMITATIONS, MIN_MONTHS, evaluate_forecast, monthly_series
from src.visualization import forecast_chart

ui.setup_page("Crime Prediction", "🔮")
st.title("🔮 Crime Prediction")
st.warning(
    "These are **statistical projections of aggregate monthly counts**, not real future events. "
    "No individual, suspect or address is predicted."
)

df = ui.require_data()

c1, c2, c3 = st.columns(3)
choices = ["All crime"] + list(category_counts(df, top_n=15)["category"])
choice = c1.selectbox("Series to forecast", choices)
test_months = c2.slider("Held-out test months", 6, 24, 12)
horizon = c3.slider("Forecast horizon (months)", 3, 24, 12)


@st.cache_data(show_spinner="Training and evaluating models…")
def run(category, test_months, horizon, rows, last_date):  # rows/last_date key the cache on the data
    series = monthly_series(df, None if category == "All crime" else category)
    return evaluate_forecast(series, test_months=test_months, horizon=horizon)


try:
    result = run(choice, test_months, horizon, len(df), str(df["date"].max()))
except ValueError as exc:
    st.error(str(exc))
    st.info(f"At least {MIN_MONTHS} complete months are required. Use the Crime Analysis page for "
            "descriptive trends instead.")
    st.stop()

st.plotly_chart(forecast_chart(result), use_container_width=True)
ui.explain("Grey/blue lines are actual history. Dotted lines are each model's forecast for the held-out "
           "test months (trained only on earlier data). The dashed red line is the forward projection.")

st.markdown("### Model performance on held-out months")
metrics = result.metrics.rename(columns={"MAPE_%": "MAPE (%)",
                                         "MAE_improvement_vs_baseline_%": "MAE vs baseline (%)"})
st.dataframe(metrics.round(2), use_container_width=True, hide_index=True)
ui.explain("MAE = average miss in incidents/month; RMSE penalises large misses more; MAPE = average "
           "percentage miss. Positive 'MAE vs baseline' means better than simply repeating last year.")

if result.beats_baseline:
    st.success(f"Best model on the test period: **{result.best_model}**.")
for note in result.notes:
    st.info(note)

with st.expander("Projection values"):
    st.dataframe(result.future.rename("projected_incidents").round(0).to_frame().reset_index()
                 .rename(columns={"index": "month"}), use_container_width=True, hide_index=True)

st.markdown("### Limitations")
for item in LIMITATIONS:
    st.markdown(f"- {item}")
