import streamlit as st

from src import ui

ui.setup_page("Data Explorer", "🗂️")
st.title("🗂️ Data Explorer")

df = ui.sidebar_filters(ui.require_data())

st.write(f"**{len(df):,}** incidents match the current filters.")
rows = st.slider("Rows to preview", 100, 5000, 1000, step=100)
st.dataframe(df.sort_values("date", ascending=False).head(rows), use_container_width=True, hide_index=True)
ui.explain("Preview of the most recent matching records. Use the sidebar filters to narrow by year, "
           "category and district.")

MAX_EXPORT = 500_000
export = df.sort_values("date", ascending=False).head(MAX_EXPORT)
if len(df) > MAX_EXPORT:
    st.info(f"Export is capped at the {MAX_EXPORT:,} most recent matching rows. Narrow the filters "
            "to export everything.")
st.download_button("⬇️ Download filtered data (CSV)", data=export.to_csv(index=False).encode("utf-8"),
                   file_name="crimescope_filtered.csv", mime="text/csv")
