"""Download Chicago crime records from the City of Chicago Data Portal (Socrata API).

Example:
    python scripts/download_data.py --start-year 2018 --end-year 2024

Optionally set SOCRATA_APP_TOKEN in your environment for higher rate limits.
The raw file is written to data/raw/ (git-ignored because of its size).
"""
from __future__ import annotations

import argparse
import os
import sys
import time
from pathlib import Path

import requests

ENDPOINT = "https://data.cityofchicago.org/resource/ijzp-q8t2.csv"
PROJECT_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_OUT = PROJECT_ROOT / "data" / "raw" / "chicago_crimes.csv"


def fetch_page(session: requests.Session, where: str, offset: int, page_size: int, retries: int = 4) -> str:
    params = {"$where": where, "$order": "id", "$limit": page_size, "$offset": offset}
    for attempt in range(1, retries + 1):
        try:
            resp = session.get(ENDPOINT, params=params, timeout=120)
            resp.raise_for_status()
            return resp.text
        except requests.RequestException as exc:
            if attempt == retries:
                raise
            wait = 2 ** attempt
            print(f"Request failed ({exc}); retrying in {wait}s...", file=sys.stderr)
            time.sleep(wait)
    raise RuntimeError("unreachable")


def download(start_year: int, end_year: int, out_path: Path, page_size: int = 50_000) -> int:
    if start_year > end_year:
        raise ValueError("--start-year must not exceed --end-year")
    session = requests.Session()
    token = os.environ.get("SOCRATA_APP_TOKEN")
    if token:
        session.headers["X-App-Token"] = token
    where = f"year >= {int(start_year)} AND year <= {int(end_year)}"
    out_path.parent.mkdir(parents=True, exist_ok=True)

    total, offset = 0, 0
    with out_path.open("w", encoding="utf-8", newline="") as fh:
        while True:
            text = fetch_page(session, where, offset, page_size)
            lines = text.splitlines(keepends=True)
            data_rows = max(len(lines) - 1, 0)
            if data_rows == 0:
                break
            fh.writelines(lines if offset == 0 else lines[1:])
            total += data_rows
            offset += page_size
            print(f"Downloaded {total:,} rows...")
            if data_rows < page_size:
                break
    return total


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--start-year", type=int, default=2018)
    parser.add_argument("--end-year", type=int, default=2024)
    parser.add_argument("--output", type=Path, default=DEFAULT_OUT)
    args = parser.parse_args()
    try:
        total = download(args.start_year, args.end_year, args.output)
    except (requests.RequestException, ValueError) as exc:
        print(f"Download failed: {exc}", file=sys.stderr)
        return 1
    print(f"Done: {total:,} rows saved to {args.output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
