"""Generate real figures and a Markdown summary of key insights from the cleaned data.

Run after cleaning:
    python scripts/generate_report.py

Outputs (all computed from the dataset, nothing hand-written):
    assets/figures/*.png
    results/key_insights.md
    results/forecast_metrics.csv
"""
from __future__ import annotations

import sys
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import seaborn as sns  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from src.data_analysis import (category_change, category_counts, headline_kpis,  # noqa: E402
                               hour_weekday_matrix, monthly_distribution, region_counts,
                               seasonal_counts, yearly_growth)
from src.data_cleaning import load_clean_data  # noqa: E402
from src.prediction import evaluate_forecast, monthly_series  # noqa: E402
from src.utils import clean_data_path, format_int, format_pct, get_logger  # noqa: E402

logger = get_logger("generate_report")
FIG_DIR, RES_DIR = ROOT / "assets" / "figures", ROOT / "results"


def _save(fig, name: str) -> None:
    fig.tight_layout()
    fig.savefig(FIG_DIR / name, dpi=150)
    plt.close(fig)


def main() -> int:
    path = clean_data_path()
    if not path.exists():
        logger.error("Cleaned data not found at %s. See data/README.md.", path)
        return 1
    FIG_DIR.mkdir(parents=True, exist_ok=True)
    RES_DIR.mkdir(parents=True, exist_ok=True)
    sns.set_theme(style="whitegrid")
    df = load_clean_data(path)

    cats = category_counts(df, 10)
    fig, ax = plt.subplots(figsize=(8, 5))
    sns.barplot(data=cats, y="category", x="incidents", ax=ax, color="#2F6FED")
    ax.set_title("Top 10 crime categories")
    _save(fig, "top_categories.png")

    growth = yearly_growth(df)
    fig, ax = plt.subplots(figsize=(8, 4.5))
    colors = ["#2F6FED" if c else "#64748B" for c in growth["is_complete"]]
    ax.bar(growth["year"].astype(str), growth["incidents"], color=colors)
    ax.set_title("Incidents per year (grey = partial year)")
    _save(fig, "yearly_incidents.png")

    monthly = monthly_distribution(df)
    fig, ax = plt.subplots(figsize=(8, 4.5))
    sns.barplot(data=monthly, x="month_name", y="incidents", ax=ax, color="#12B5A6")
    ax.set_title("Incidents by calendar month (complete years)")
    _save(fig, "monthly_distribution.png")

    fig, ax = plt.subplots(figsize=(10, 4.5))
    sns.heatmap(hour_weekday_matrix(df), cmap="viridis", ax=ax)
    ax.set_title("Incidents by weekday and hour")
    _save(fig, "hour_weekday_heatmap.png")

    # Forecast
    forecast_lines: list[str] = []
    try:
        result = evaluate_forecast(monthly_series(df))
        result.metrics.to_csv(RES_DIR / "forecast_metrics.csv", index=False)
        fig, ax = plt.subplots(figsize=(10, 4.5))
        ax.plot(result.train.index, result.train, label="Actual (train)", color="#64748B")
        ax.plot(result.test.index, result.test, label="Actual (test)", color="#2F6FED", lw=2.5)
        for name, pred in result.predictions.items():
            ax.plot(pred.index, pred, ls=":", label=name)
        ax.plot(result.future.index, result.future, ls="--", color="#E4572E", label="Projection")
        ax.legend(fontsize=7)
        ax.set_title("Monthly incidents: actual vs predicted")
        _save(fig, "forecast.png")
        forecast_lines = ["", "## Forecast evaluation (held-out last 12 months, all crime)", "",
                          result.metrics.round(2).to_markdown(index=False) if _has_tabulate()
                          else result.metrics.round(2).to_string(index=False),
                          "", f"Best model on held-out months: **{result.best_model}**."]
        forecast_lines += [f"Note: {n}" for n in result.notes]
    except ValueError as exc:
        forecast_lines = ["", "## Forecast", "", f"Forecast not produced: {exc}"]

    kpis = headline_kpis(df)
    lines = ["# Key insights (generated from the data)", "",
             f"- Records analysed: **{format_int(kpis['total'])}** "
             f"({df['date'].min():%Y-%m-%d} to {df['date'].max():%Y-%m-%d})",
             f"- Most common category: **{kpis['top_category']}** "
             f"({format_int(kpis['top_category_count'])} incidents)"]
    if kpis["top_district"] is not None:
        top_d = region_counts(df, "district").iloc[0]
        lines.append(f"- Highest-count police district: **District {int(top_d['district'])}** "
                     f"({top_d['share_pct']:.1f}% of incidents with a district)")
    if kpis["yoy_years"]:
        a, b = kpis["yoy_years"]
        lines.append(f"- Total incidents {a} to {b}: **{format_pct(kpis['yoy_pct'])}**")
    season = seasonal_counts(df).sort_values("incidents", ascending=False)
    lines.append(f"- Season with the most incidents (complete years): **{season.iloc[0]['season']}**")
    peak = monthly.sort_values("incidents", ascending=False).iloc[0]
    lines.append(f"- Calendar month with the most incidents (complete years): **{peak['month_name']}**")
    years = sorted(df["year"].unique())
    full = growth[growth["is_complete"]]["year"].tolist()
    if len(full) >= 2:
        change = category_change(df, full[0], full[-1], top_n=15).dropna(subset=["pct_change"])
        up, down = change.sort_values("pct_change").iloc[-1], change.sort_values("pct_change").iloc[0]
        lines.append(f"- Among the 15 largest categories, {full[0]} to {full[-1]}: biggest increase "
                     f"**{up['category']}** ({format_pct(up['pct_change'])}), biggest decrease "
                     f"**{down['category']}** ({format_pct(down['pct_change'])})")
    lines += forecast_lines
    (RES_DIR / "key_insights.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    logger.info("Wrote %s and figures in %s", RES_DIR / "key_insights.md", FIG_DIR)
    return 0


def _has_tabulate() -> bool:
    try:
        import tabulate  # noqa: F401
        return True
    except ImportError:
        return False


if __name__ == "__main__":
    raise SystemExit(main())
