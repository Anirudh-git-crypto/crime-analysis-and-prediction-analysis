"""CrimeScope core package: data cleaning, analysis, forecasting and plotting."""
