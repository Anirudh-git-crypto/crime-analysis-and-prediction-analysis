"""Descriptive analysis functions. All functions are pure (DataFrame in, DataFrame/dict out)."""
from __future__ import annotations

import math
from typing import Iterable, Optional

import numpy as np
import pandas as pd

from src.utils import safe_pct_change

SEASON_ORDER = ["Winter", "Spring", "Summer", "Autumn"]
DAY_ORDER = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
MONTH_NAMES = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
REGION_COLUMNS = ("district", "community_area", "ward", "beat")


def apply_filters(
    df: pd.DataFrame,
    years: Optional[tuple[int, int]] = None,
    categories: Optional[Iterable[str]] = None,
    districts: Optional[Iterable[float]] = None,
) -> pd.DataFrame:
    """Filter by inclusive year range, category list and district list (empty = no filter)."""
    out = df
    if years is not None:
        out = out[out["year"].between(years[0], years[1])]
    categories = list(categories) if categories else []
    if categories:
        out = out[out["primary_type"].isin(categories)]
    districts = list(districts) if districts else []
    if districts and "district" in out.columns:
        out = out[out["district"].isin(districts)]
    return out


def total_incidents(df: pd.DataFrame) -> int:
    return int(len(df))


def category_counts(df: pd.DataFrame, top_n: Optional[int] = None) -> pd.DataFrame:
    """Incidents and share (%) per category, sorted descending."""
    counts = df["primary_type"].value_counts().rename_axis("category").reset_index(name="incidents")
    total = counts["incidents"].sum()
    counts["share_pct"] = counts["incidents"] / total * 100 if total else np.nan
    return counts.head(top_n) if top_n else counts


def yearly_counts(df: pd.DataFrame) -> pd.DataFrame:
    """Incidents per year, with how many calendar months each year covers."""
    grouped = df.groupby("year")
    out = grouped.size().rename("incidents").to_frame()
    out["months_covered"] = grouped["month"].nunique()
    out["is_complete"] = out["months_covered"] == 12
    return out.reset_index()


def yearly_growth(df: pd.DataFrame) -> pd.DataFrame:
    """Year-over-year % change. Only computed between two *complete*, consecutive years,
    because comparing a partial year to a full year would be misleading."""
    y = yearly_counts(df)
    changes = [math.nan]
    for i in range(1, len(y)):
        prev, cur = y.iloc[i - 1], y.iloc[i]
        comparable = bool(prev["is_complete"] and cur["is_complete"] and cur["year"] == prev["year"] + 1)
        changes.append(safe_pct_change(cur["incidents"], prev["incidents"]) if comparable else math.nan)
    y["pct_change"] = changes
    return y


def _complete_years_only(df: pd.DataFrame) -> pd.DataFrame:
    months = df.groupby("year")["month"].nunique()
    complete = months[months == 12].index
    return df[df["year"].isin(complete)] if len(complete) else df


def monthly_distribution(df: pd.DataFrame, complete_years_only: bool = True) -> pd.DataFrame:
    """Total incidents by calendar month (Jan-Dec)."""
    base = _complete_years_only(df) if complete_years_only else df
    counts = base.groupby("month").size().reindex(range(1, 13), fill_value=0)
    out = counts.rename("incidents").reset_index()
    out["month_name"] = [MONTH_NAMES[m - 1] for m in out["month"]]
    return out


def monthly_trend(df: pd.DataFrame) -> pd.DataFrame:
    """Incidents per calendar month across the full time span."""
    return df.groupby("month_start").size().rename("incidents").reset_index()


def seasonal_counts(df: pd.DataFrame, complete_years_only: bool = True) -> pd.DataFrame:
    base = _complete_years_only(df) if complete_years_only else df
    counts = base.groupby("season").size().reindex(SEASON_ORDER, fill_value=0)
    return counts.rename("incidents").reset_index()


def category_year_matrix(df: pd.DataFrame, top_n: int = 10) -> pd.DataFrame:
    """Incidents per (category x year) for the ``top_n`` most frequent categories."""
    top = df["primary_type"].value_counts().head(top_n).index
    return (df[df["primary_type"].isin(top)]
            .pivot_table(index="primary_type", columns="year", values="month",
                         aggfunc="size", fill_value=0))


def category_change(
    df: pd.DataFrame, start_year: int, end_year: int, top_n: Optional[int] = None
) -> pd.DataFrame:
    """Compare category counts between two years with safe % change."""
    years = set(df["year"].unique())
    if start_year not in years or end_year not in years:
        raise ValueError("Both years must exist in the data.")
    if start_year == end_year:
        raise ValueError("Choose two different years.")
    a = df[df["year"] == start_year]["primary_type"].value_counts()
    b = df[df["year"] == end_year]["primary_type"].value_counts()
    out = pd.concat([a.rename("count_start"), b.rename("count_end")], axis=1).fillna(0).astype(int)
    out["abs_change"] = out["count_end"] - out["count_start"]
    out["pct_change"] = [safe_pct_change(e, s) for s, e in zip(out["count_start"], out["count_end"])]

    def direction(row: pd.Series) -> str:
        if row["count_start"] == 0 and row["count_end"] > 0:
            return "New (no baseline)"
        if row["abs_change"] > 0:
            return "Increase"
        if row["abs_change"] < 0:
            return "Decrease"
        return "No change"

    out["direction"] = out.apply(direction, axis=1)
    out = out.sort_values("count_end", ascending=False).rename_axis("category").reset_index()
    return out.head(top_n) if top_n else out


def region_counts(df: pd.DataFrame, by: str = "district", top_n: Optional[int] = None) -> pd.DataFrame:
    """Incidents per region column (district, community area, ...)."""
    if by not in REGION_COLUMNS:
        raise ValueError(f"'by' must be one of {REGION_COLUMNS}")
    if by not in df.columns:
        raise ValueError(f"Column '{by}' is not in the data.")
    valid = df.dropna(subset=[by])
    counts = valid[by].astype(int).value_counts().rename_axis(by).reset_index(name="incidents")
    total = counts["incidents"].sum()
    counts["share_pct"] = counts["incidents"] / total * 100 if total else np.nan
    return counts.head(top_n) if top_n else counts


def hour_weekday_matrix(df: pd.DataFrame) -> pd.DataFrame:
    """Incidents by weekday (rows) and hour of day (columns)."""
    matrix = df.pivot_table(index="day_of_week", columns="hour", values="year",
                            aggfunc="size", fill_value=0)
    return matrix.reindex(DAY_ORDER).reindex(columns=range(24), fill_value=0).fillna(0)


def location_points(df: pd.DataFrame, max_points: int = 50_000, seed: int = 42) -> pd.DataFrame:
    """Rows with valid coordinates, randomly sampled for fast map rendering."""
    if not {"latitude", "longitude"} <= set(df.columns):
        return pd.DataFrame(columns=["latitude", "longitude"])
    pts = df.dropna(subset=["latitude", "longitude"])[["latitude", "longitude"]]
    return pts.sample(n=max_points, random_state=seed) if len(pts) > max_points else pts


def headline_kpis(df: pd.DataFrame) -> dict:
    """KPIs for the overview page. YoY uses the two latest consecutive complete years."""
    if df.empty:
        return {"total": 0, "top_category": None, "top_category_count": 0,
                "top_district": None, "yoy_pct": math.nan, "yoy_years": None}
    cats = category_counts(df)
    kpis = {
        "total": total_incidents(df),
        "top_category": cats.iloc[0]["category"],
        "top_category_count": int(cats.iloc[0]["incidents"]),
        "top_district": None,
        "yoy_pct": math.nan,
        "yoy_years": None,
    }
    if "district" in df.columns and df["district"].notna().any():
        kpis["top_district"] = int(region_counts(df, "district").iloc[0]["district"])
    growth = yearly_growth(df).dropna(subset=["pct_change"])
    if not growth.empty:
        last = growth.iloc[-1]
        kpis["yoy_pct"] = float(last["pct_change"])
        kpis["yoy_years"] = (int(last["year"]) - 1, int(last["year"]))
    return kpis
