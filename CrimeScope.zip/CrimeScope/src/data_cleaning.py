"""Reusable cleaning pipeline for the City of Chicago "Crimes - 2001 to Present" data.

Every step is a small function so it can be tested on its own. ``clean_crime_data``
chains them and returns a report of exactly what was changed or removed.

Usage::

    python -m src.data_cleaning --input data/raw/chicago_crimes.csv \
        --output data/processed/crimes_clean.csv
"""
from __future__ import annotations

import argparse
from pathlib import Path
from typing import Optional

import numpy as np
import pandas as pd

from src.utils import get_logger

logger = get_logger(__name__)

CHICAGO_DATE_FORMAT = "%m/%d/%Y %I:%M:%S %p"
MIN_PLAUSIBLE_DATE = pd.Timestamp("2001-01-01")
# Approximate bounding box of the City of Chicago, used to reject bad coordinates.
LAT_RANGE = (41.60, 42.05)
LON_RANGE = (-87.95, -87.50)

REQUIRED_COLUMNS = ("date", "primary_type")
KEEP_COLUMNS = (
    "id", "case_number", "date", "block", "primary_type", "description",
    "location_description", "arrest", "domestic", "beat", "district", "ward",
    "community_area", "latitude", "longitude",
)
# Inconsistent labels that appear in the source data for the same category.
CATEGORY_ALIASES = {
    "CRIM SEXUAL ASSAULT": "CRIMINAL SEXUAL ASSAULT",
    "NON-CRIMINAL (SUBJECT SPECIFIED)": "NON-CRIMINAL",
    "NON - CRIMINAL": "NON-CRIMINAL",
}
SEASONS = {12: "Winter", 1: "Winter", 2: "Winter", 3: "Spring", 4: "Spring",
           5: "Spring", 6: "Summer", 7: "Summer", 8: "Summer", 9: "Autumn",
           10: "Autumn", 11: "Autumn"}


class DataValidationError(ValueError):
    """Raised when the cleaned dataset fails a validation check."""


def standardize_columns(df: pd.DataFrame) -> pd.DataFrame:
    """Convert column names to lowercase snake_case (``Primary Type`` -> ``primary_type``)."""
    out = df.copy()
    out.columns = (
        out.columns.astype(str).str.strip().str.lower()
        .str.replace(r"[^0-9a-z]+", "_", regex=True).str.strip("_")
    )
    return out


def parse_dates(series: pd.Series) -> pd.Series:
    """Parse dates using the portal's format, falling back to generic parsing.

    Values that cannot be parsed become ``NaT`` and are removed later.
    """
    parsed = pd.to_datetime(series, format=CHICAGO_DATE_FORMAT, errors="coerce")
    leftover = parsed.isna() & series.notna()
    if leftover.any():
        parsed.loc[leftover] = pd.to_datetime(series[leftover], errors="coerce")
    return parsed


def normalize_categories(series: pd.Series) -> pd.Series:
    """Trim, upper-case, collapse whitespace and merge known alias labels."""
    cleaned = (
        series.astype("string").str.strip().str.upper()
        .str.replace(r"\s+", " ", regex=True)
    )
    return cleaned.replace(CATEGORY_ALIASES)


def clean_coordinates(df: pd.DataFrame) -> tuple[pd.DataFrame, int]:
    """Null out coordinates that are non-numeric, zero or outside Chicago.

    Latitude and longitude are only kept as a valid pair. Returns the frame and
    the number of rows whose coordinates were invalidated (excluding rows that
    simply had no coordinates).
    """
    out = df.copy()
    if not {"latitude", "longitude"}.issubset(out.columns):
        return out, 0
    lat = pd.to_numeric(out["latitude"], errors="coerce")
    lon = pd.to_numeric(out["longitude"], errors="coerce")
    had_values = lat.notna() | lon.notna()
    valid = (lat.between(*LAT_RANGE)) & (lon.between(*LON_RANGE))
    invalid_count = int((had_values & ~valid).sum())
    out["latitude"] = lat.where(valid)
    out["longitude"] = lon.where(valid)
    return out, invalid_count


def _to_bool(series: pd.Series) -> pd.Series:
    if series.dtype == bool:
        return series
    return series.astype("string").str.strip().str.lower().isin(["true", "1", "y", "yes"])


def add_time_features(df: pd.DataFrame) -> pd.DataFrame:
    """Derive year, month, hour, weekday, season and month-start from ``date``."""
    out = df.copy()
    out["year"] = out["date"].dt.year.astype(int)
    out["month"] = out["date"].dt.month.astype(int)
    out["month_start"] = out["date"].dt.to_period("M").dt.to_timestamp()
    out["hour"] = out["date"].dt.hour.astype(int)
    out["day_of_week"] = out["date"].dt.day_name()
    out["season"] = out["month"].map(SEASONS)
    return out


def daily_count_outliers(df: pd.DataFrame, factor: float = 3.0) -> pd.DataFrame:
    """Identify extreme days using the IQR rule on daily incident counts.

    Outlier days are *reported, not removed*: unusually high or low days can be
    real events (holidays, the 2020 lockdowns) rather than data errors.
    """
    daily = df.groupby(df["date"].dt.normalize()).size().rename("incidents")
    q1, q3 = daily.quantile(0.25), daily.quantile(0.75)
    iqr = q3 - q1
    low, high = q1 - factor * iqr, q3 + factor * iqr
    flagged = daily[(daily < low) | (daily > high)]
    return flagged.reset_index().rename(columns={"date": "day"})


def validate_clean_data(df: pd.DataFrame) -> dict[str, bool]:
    """Run integrity checks on a cleaned frame; raise if any check fails."""
    checks = {
        "non_empty": len(df) > 0,
        "date_is_datetime": pd.api.types.is_datetime64_any_dtype(df.get("date")),
        "no_missing_date": bool(df["date"].notna().all()) if "date" in df else False,
        "no_missing_category": bool(df["primary_type"].notna().all()) if "primary_type" in df else False,
        "id_unique": bool(df["id"].is_unique) if "id" in df else True,
        "year_matches_date": bool((df["year"] == df["date"].dt.year).all()) if {"year", "date"} <= set(df) else False,
        "coordinates_in_bounds": True,
    }
    if {"latitude", "longitude"} <= set(df):
        coords = df[["latitude", "longitude"]].dropna()
        checks["coordinates_in_bounds"] = bool(
            coords["latitude"].between(*LAT_RANGE).all()
            and coords["longitude"].between(*LON_RANGE).all()
        )
    failed = [name for name, ok in checks.items() if not ok]
    if failed:
        raise DataValidationError(f"Validation failed: {', '.join(failed)}")
    return checks


def clean_crime_data(
    raw: pd.DataFrame, today: Optional[pd.Timestamp] = None
) -> tuple[pd.DataFrame, dict]:
    """Clean a raw Chicago crimes frame.

    Steps: standardize columns -> keep relevant columns -> parse dates ->
    drop rows with missing/implausible dates or categories -> remove duplicates
    -> normalize categories -> validate coordinates -> cast types ->
    add time features -> validate.

    Returns ``(clean_frame, report)`` where ``report`` counts what happened.
    """
    today = today or pd.Timestamp.now()
    report: dict = {"rows_raw": int(len(raw))}

    df = standardize_columns(raw)
    missing = [c for c in REQUIRED_COLUMNS if c not in df.columns]
    if missing:
        raise DataValidationError(f"Missing required columns: {missing}")
    df = df[[c for c in KEEP_COLUMNS if c in df.columns]].copy()

    df["date"] = parse_dates(df["date"])
    report["unparseable_dates"] = int(df["date"].isna().sum())

    df["primary_type"] = normalize_categories(df["primary_type"])
    report["missing_category"] = int(df["primary_type"].isna().sum())

    before = len(df)
    df = df.dropna(subset=["date", "primary_type"])
    report["dropped_missing_date_or_category"] = before - len(df)

    before = len(df)
    in_range = (df["date"] >= MIN_PLAUSIBLE_DATE) & (df["date"] <= today + pd.Timedelta(days=1))
    df = df[in_range]
    report["dropped_implausible_dates"] = before - len(df)

    before = len(df)
    if "id" in df.columns:
        df = df.drop_duplicates(subset="id", keep="first")
    df = df.drop_duplicates(keep="first")
    report["duplicates_removed"] = before - len(df)

    df, report["invalid_coordinates_nulled"] = clean_coordinates(df)

    if "location_description" in df.columns:
        df["location_description"] = (
            df["location_description"].astype("string").str.strip().str.upper().fillna("UNKNOWN")
        )
    for col in ("arrest", "domestic"):
        if col in df.columns:
            df[col] = _to_bool(df[col])
    for col in ("beat", "district", "ward", "community_area"):
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors="coerce")

    df = add_time_features(df).sort_values("date").reset_index(drop=True)

    report["rows_clean"] = int(len(df))
    report["missing_values"] = {c: int(n) for c, n in df.isna().sum().items() if n > 0}
    report["outlier_days"] = int(len(daily_count_outliers(df)))
    report["validation"] = validate_clean_data(df)
    logger.info("Cleaned %s -> %s rows", report["rows_raw"], report["rows_clean"])
    return df, report


def load_clean_data(path: Path | str) -> pd.DataFrame:
    """Load the cleaned CSV produced by this pipeline."""
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(
            f"Cleaned dataset not found at {path}. See data/README.md for how to "
            "download and clean the data."
        )
    return pd.read_csv(path, parse_dates=["date", "month_start"], low_memory=False)


def main(argv: Optional[list[str]] = None) -> int:
    parser = argparse.ArgumentParser(description="Clean the Chicago crimes CSV.")
    parser.add_argument("--input", required=True, type=Path, help="raw CSV path")
    parser.add_argument("--output", required=True, type=Path, help="cleaned CSV path")
    args = parser.parse_args(argv)

    if not args.input.exists():
        logger.error("Input file not found: %s", args.input)
        return 1
    raw = pd.read_csv(args.input, low_memory=False)
    clean, report = clean_crime_data(raw)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    clean.to_csv(args.output, index=False)
    for key, value in report.items():
        logger.info("%s: %s", key, value)
    logger.info("Wrote %s", args.output)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
