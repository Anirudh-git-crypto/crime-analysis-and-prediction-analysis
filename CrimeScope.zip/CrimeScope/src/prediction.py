"""Aggregate monthly crime-count forecasting.

Scope: forecasts *aggregate counts* (all crime or one category) per month. It never
models individuals, suspects or specific locations.

Method: a seasonal-naive baseline is compared with two regression models trained on
lag and calendar features. The split is strictly chronological (the last
``test_months`` months are held out) and test forecasts are *recursive*: the model
never sees test-period actuals, so there is no leakage.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

import numpy as np
import pandas as pd
from sklearn.ensemble import GradientBoostingRegressor
from sklearn.linear_model import Ridge
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

from src.utils import get_logger

logger = get_logger(__name__)

MIN_MONTHS = 36
MAX_LAG = 12
BASELINE = "Seasonal naive (same month last year)"
MODEL_FACTORIES = {
    "Ridge regression (lags + seasonality)": lambda: make_pipeline(StandardScaler(), Ridge(alpha=1.0)),
    "Gradient boosting (lags + seasonality)": lambda: GradientBoostingRegressor(
        n_estimators=200, max_depth=2, learning_rate=0.05, random_state=42),
}


@dataclass
class ForecastResult:
    series: pd.Series
    train: pd.Series
    test: pd.Series
    predictions: dict[str, pd.Series]
    metrics: pd.DataFrame
    best_model: str
    future: pd.Series
    beats_baseline: bool
    notes: list[str] = field(default_factory=list)


def monthly_series(df: pd.DataFrame, category: Optional[str] = None) -> pd.Series:
    """Monthly incident counts, dropping incomplete first/last months.

    A month is treated as incomplete if the data starts after day 3 of it or ends
    more than one day before it finishes (the portal lags real time).
    """
    if category:
        df = df[df["primary_type"] == category]
    if df.empty:
        raise ValueError("No data for the selected category.")
    counts = df.groupby("month_start").size()
    full = pd.date_range(counts.index.min(), counts.index.max(), freq="MS")
    counts = counts.reindex(full, fill_value=0).astype(float)

    first_day, last_day = df["date"].min(), df["date"].max()
    if first_day.day > 3 and len(counts) > 1:
        counts = counts.iloc[1:]
    month_end = counts.index[-1] + pd.offsets.MonthEnd(0)
    if last_day.normalize() < month_end.normalize() - pd.Timedelta(days=1) and len(counts) > 1:
        counts = counts.iloc[:-1]
    counts.index.name = "month_start"
    return counts


def _feature_row(values: list[float], date: pd.Timestamp, t: int) -> list[float]:
    angle = 2 * np.pi * date.month / 12
    return [values[-1], values[-2], values[-3], values[-12], np.sin(angle), np.cos(angle), float(t)]


def build_training_matrix(series: pd.Series) -> tuple[np.ndarray, np.ndarray]:
    """Lag/calendar features for each month that has 12 months of history."""
    values = series.to_numpy(dtype=float).tolist()
    X, y = [], []
    for i in range(MAX_LAG, len(values)):
        X.append(_feature_row(values[:i], series.index[i], i))
        y.append(values[i])
    return np.asarray(X), np.asarray(y)


def recursive_forecast(model, history: pd.Series, steps: int) -> pd.Series:
    """Forecast ``steps`` months ahead, feeding predictions back in as lags."""
    values = history.to_numpy(dtype=float).tolist()
    dates = pd.date_range(history.index[-1] + pd.offsets.MonthBegin(1), periods=steps, freq="MS")
    preds = []
    for date in dates:
        row = np.asarray([_feature_row(values, date, len(values))])
        pred = max(float(model.predict(row)[0]), 0.0)
        preds.append(pred)
        values.append(pred)
    return pd.Series(preds, index=dates, name="forecast")


def seasonal_naive_forecast(history: pd.Series, steps: int) -> pd.Series:
    """Repeat the last 12 observed months."""
    last_year = history.to_numpy(dtype=float)[-12:]
    dates = pd.date_range(history.index[-1] + pd.offsets.MonthBegin(1), periods=steps, freq="MS")
    return pd.Series([last_year[h % 12] for h in range(steps)], index=dates, name="forecast")


def regression_metrics(actual: pd.Series, predicted: pd.Series) -> dict[str, float]:
    """MAE, RMSE and MAPE (MAPE skips months where the actual value is zero)."""
    a, p = actual.to_numpy(dtype=float), predicted.to_numpy(dtype=float)
    err = a - p
    nonzero = a != 0
    mape = float(np.mean(np.abs(err[nonzero] / a[nonzero])) * 100) if nonzero.any() else float("nan")
    return {"MAE": float(np.mean(np.abs(err))), "RMSE": float(np.sqrt(np.mean(err ** 2))), "MAPE_%": mape}


def _fit(name: str, series: pd.Series):
    X, y = build_training_matrix(series)
    model = MODEL_FACTORIES[name]()
    model.fit(X, y)
    return model


def evaluate_forecast(series: pd.Series, test_months: int = 12, horizon: int = 12) -> ForecastResult:
    """Chronologically split, compare baseline vs regression models, then forecast ahead.

    Raises ``ValueError`` if the series is too short for a reliable evaluation.
    """
    if len(series) < MIN_MONTHS:
        raise ValueError(
            f"Only {len(series)} complete months available; at least {MIN_MONTHS} are "
            "needed for a reliable forecast evaluation. Showing descriptive trends instead."
        )
    if not 3 <= test_months <= len(series) // 3:
        raise ValueError(f"test_months must be between 3 and {len(series) // 3}.")
    if horizon < 1:
        raise ValueError("horizon must be at least 1.")

    train, test = series.iloc[:-test_months], series.iloc[-test_months:]
    assert train.index.max() < test.index.min()  # chronological, no overlap

    predictions = {BASELINE: seasonal_naive_forecast(train, test_months)}
    for name in MODEL_FACTORIES:
        predictions[name] = recursive_forecast(_fit(name, train), train, test_months)

    rows = []
    for name, pred in predictions.items():
        rows.append({"model": name, **regression_metrics(test, pred)})
    metrics = pd.DataFrame(rows)
    base_mae = metrics.loc[metrics["model"] == BASELINE, "MAE"].iloc[0]
    metrics["MAE_improvement_vs_baseline_%"] = (
        (base_mae - metrics["MAE"]) / base_mae * 100 if base_mae else np.nan)
    metrics = metrics.sort_values("MAE").reset_index(drop=True)

    best = metrics.iloc[0]["model"]
    beats = best != BASELINE
    if best == BASELINE:
        future = seasonal_naive_forecast(series, horizon)
    else:
        future = recursive_forecast(_fit(best, series), series, horizon)

    notes = []
    if not beats:
        notes.append("Neither regression model beat the seasonal-naive baseline on the "
                     "held-out months, so the baseline is used for the forward projection.")
    logger.info("Best model on test set: %s", best)
    return ForecastResult(series=series, train=train, test=test, predictions=predictions,
                          metrics=metrics, best_model=best, future=future,
                          beats_baseline=beats, notes=notes)


LIMITATIONS = [
    "Forecasts are statistical projections of aggregate monthly counts, not predictions of real events.",
    "Models learn only from past counts; they cannot anticipate policy changes, economic shifts or events like the 2020 pandemic.",
    "Recorded crime reflects reporting and policing practices as well as underlying crime.",
    "Accuracy is judged on a single held-out period, so the metrics are noisy estimates of future performance.",
    "Forecast uncertainty grows with the horizon; treat long-range values as indicative at best.",
    "No individual, suspect or address-level prediction is made or supported.",
]
