"""Streamlit UI helpers shared by app.py and every page (theme, KPI cards, data loading, filters)."""
from __future__ import annotations

import html
from pathlib import Path

import pandas as pd
import streamlit as st

from src.data_analysis import apply_filters
from src.data_cleaning import load_clean_data
from src.utils import clean_data_path, get_logger

logger = get_logger(__name__)

_CSS = """
<style>
.cs-kpi {border: 1px solid rgba(128,128,128,.28); border-radius: 14px; padding: 1rem 1.2rem;
         background: rgba(128,128,128,.07); height: 100%;}
.cs-kpi .cs-label {font-size: .78rem; letter-spacing: .06em; text-transform: uppercase; opacity: .7;}
.cs-kpi .cs-value {font-size: 1.9rem; font-weight: 700; line-height: 1.25;}
.cs-kpi .cs-delta {font-size: .85rem; opacity: .85;}
.cs-up {color: #E4572E;} .cs-down {color: #12B5A6;}
h1, h2, h3 {letter-spacing: -.01em;}
</style>
"""


def setup_page(title: str, icon: str = "🔎") -> None:
    """Configure page chrome and inject shared CSS. Call first on every page."""
    st.set_page_config(page_title=f"{title} · CrimeScope", page_icon=icon, layout="wide")
    st.markdown(_CSS, unsafe_allow_html=True)


def kpi_card(label: str, value: str, delta: str | None = None, delta_kind: str | None = None) -> None:
    """Render a KPI card. ``delta_kind`` is 'up' or 'down' (colours only; not a value judgement)."""
    delta_html = ""
    if delta:
        cls = {"up": "cs-up", "down": "cs-down"}.get(delta_kind or "", "")
        delta_html = f'<div class="cs-delta {cls}">{html.escape(delta)}</div>'
    st.markdown(
        f'<div class="cs-kpi"><div class="cs-label">{html.escape(label)}</div>'
        f'<div class="cs-value">{html.escape(value)}</div>{delta_html}</div>',
        unsafe_allow_html=True,
    )


def explain(text: str) -> None:
    """One-line plain-English explanation under a chart."""
    st.caption(f"ℹ️ {text}")


@st.cache_data(show_spinner="Loading crime data…")
def _load(path_str: str, mtime: float) -> pd.DataFrame:  # mtime busts the cache when file changes
    return load_clean_data(path_str)


def require_data() -> pd.DataFrame:
    """Load the cleaned dataset or show a helpful error and stop the page."""
    path = clean_data_path()
    if not Path(path).exists():
        st.error("Cleaned dataset not found.")
        st.info(
            "Download and clean the data first:\n\n"
            "```bash\npython scripts/download_data.py --start-year 2018 --end-year 2024\n"
            "python -m src.data_cleaning --input data/raw/chicago_crimes.csv "
            "--output data/processed/crimes_clean.csv\n```\nSee `data/README.md` for details."
        )
        st.stop()
    try:
        return _load(str(path), Path(path).stat().st_mtime)
    except Exception as exc:  # surface any parse problem to the user instead of a traceback
        logger.exception("Failed to load data")
        st.error(f"Could not load the dataset: {exc}")
        st.stop()


def sidebar_filters(df: pd.DataFrame, with_category: bool = True, with_district: bool = True) -> pd.DataFrame:
    """Render sidebar filters and return the filtered frame (stops the page if empty)."""
    st.sidebar.header("Filters")
    lo, hi = int(df["year"].min()), int(df["year"].max())
    years = (lo, hi) if lo == hi else st.sidebar.slider("Year range", lo, hi, (lo, hi))
    categories, districts = [], []
    if with_category:
        categories = st.sidebar.multiselect("Crime category", sorted(df["primary_type"].unique()),
                                            help="Leave empty to include all categories.")
    if with_district and "district" in df.columns:
        options = sorted(int(d) for d in df["district"].dropna().unique())
        districts = st.sidebar.multiselect("Police district", options,
                                           help="Leave empty to include all districts.")
    filtered = apply_filters(df, years, categories, districts)
    if filtered.empty:
        st.warning("No incidents match the current filters. Widen the selection in the sidebar.")
        st.stop()
    st.sidebar.caption(f"{len(filtered):,} incidents selected")
    return filtered
