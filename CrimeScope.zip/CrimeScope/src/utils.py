"""Shared helpers: project paths, logging and safe arithmetic."""
from __future__ import annotations

import logging
import math
import os
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
DATA_ENV_VAR = "CRIMESCOPE_DATA"
DEFAULT_CLEAN_PATH = PROJECT_ROOT / "data" / "processed" / "crimes_clean.csv"

_LOG_FORMAT = "%(asctime)s | %(levelname)s | %(name)s | %(message)s"


def get_logger(name: str) -> logging.Logger:
    """Return a module logger, configuring the root logger once."""
    if not logging.getLogger().handlers:
        logging.basicConfig(level=logging.INFO, format=_LOG_FORMAT)
    return logging.getLogger(name)


def clean_data_path() -> Path:
    """Location of the cleaned dataset.

    Can be overridden with the ``CRIMESCOPE_DATA`` environment variable so no
    machine-specific path is ever hardcoded.
    """
    override = os.environ.get(DATA_ENV_VAR)
    return Path(override).expanduser() if override else DEFAULT_CLEAN_PATH


def safe_pct_change(new: float, old: float) -> float:
    """Percentage change from ``old`` to ``new``.

    Returns NaN when the baseline is missing or zero instead of dividing by
    zero or reporting an infinite change.
    """
    if old is None or new is None:
        return math.nan
    try:
        if math.isnan(old) or math.isnan(new) or old == 0:
            return math.nan
    except TypeError:
        return math.nan
    return (new - old) / abs(old) * 100.0


def format_int(value: float) -> str:
    """Format a number with thousands separators."""
    return f"{int(value):,}"


def format_pct(value: float, signed: bool = True) -> str:
    """Format a percentage, showing ``n/a`` for NaN."""
    if value is None or (isinstance(value, float) and math.isnan(value)):
        return "n/a"
    return f"{value:+.1f}%" if signed else f"{value:.1f}%"
