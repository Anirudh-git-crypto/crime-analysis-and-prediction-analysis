"""Plotly chart builders used by the Streamlit dashboard.

Charts take plain DataFrames produced by ``src.data_analysis`` so they always
reflect real, validated calculations. Plotly is imported at module level; it is
listed in requirements.txt.
"""
from __future__ import annotations

import pandas as pd
import plotly.express as px
import plotly.graph_objects as go

from src.prediction import ForecastResult

PALETTE = ["#2F6FED", "#12B5A6", "#F59E0B", "#E4572E", "#8B5CF6", "#64748B"]
_LAYOUT = dict(margin=dict(l=10, r=10, t=50, b=10), font=dict(family="sans-serif"))


def _style(fig: go.Figure, title: str, height: int = 420) -> go.Figure:
    fig.update_layout(title=title, height=height, **_LAYOUT)
    return fig


def bar_categories(counts: pd.DataFrame, title: str = "Incidents by category") -> go.Figure:
    data = counts.sort_values("incidents")
    fig = px.bar(data, x="incidents", y="category", orientation="h",
                 color_discrete_sequence=[PALETTE[0]],
                 hover_data={"share_pct": ":.1f"})
    return _style(fig, title, height=max(360, 32 * len(data) + 120))


def yearly_trend(yearly: pd.DataFrame, title: str = "Incidents per year") -> go.Figure:
    data = yearly.copy()
    data["coverage"] = data["is_complete"].map({True: "Complete year", False: "Partial year"})
    fig = px.bar(data, x="year", y="incidents", color="coverage",
                 color_discrete_map={"Complete year": PALETTE[0], "Partial year": PALETTE[5]},
                 hover_data=["months_covered"])
    fig.update_xaxes(type="category")
    return _style(fig, title)


def category_lines(df: pd.DataFrame, categories: list[str], title: str = "Yearly trend by category") -> go.Figure:
    data = (df[df["primary_type"].isin(categories)]
            .groupby(["year", "primary_type"]).size().rename("incidents").reset_index())
    fig = px.line(data, x="year", y="incidents", color="primary_type", markers=True,
                  color_discrete_sequence=PALETTE)
    fig.update_xaxes(dtick=1)
    return _style(fig, title)


def monthly_bar(monthly: pd.DataFrame, title: str = "Incidents by calendar month") -> go.Figure:
    fig = px.bar(monthly, x="month_name", y="incidents", color_discrete_sequence=[PALETTE[1]])
    fig.update_xaxes(categoryorder="array", categoryarray=list(monthly["month_name"]))
    return _style(fig, title)


def seasonal_bar(seasonal: pd.DataFrame, title: str = "Incidents by season") -> go.Figure:
    fig = px.bar(seasonal, x="season", y="incidents", color_discrete_sequence=[PALETTE[2]])
    return _style(fig, title, height=360)


def category_year_heatmap(matrix: pd.DataFrame, title: str = "Category x year (incidents)") -> go.Figure:
    fig = px.imshow(matrix, aspect="auto", color_continuous_scale="Blues",
                    labels=dict(x="Year", y="Category", color="Incidents"))
    fig.update_xaxes(type="category")
    return _style(fig, title, height=max(360, 36 * len(matrix) + 120))


def category_change_bar(change: pd.DataFrame, title: str) -> go.Figure:
    data = change.dropna(subset=["pct_change"]).sort_values("pct_change")
    fig = px.bar(data, x="pct_change", y="category", orientation="h", color="direction",
                 color_discrete_map={"Increase": PALETTE[3], "Decrease": PALETTE[1], "No change": PALETTE[5]},
                 hover_data=["count_start", "count_end"])
    fig.update_xaxes(title="% change")
    return _style(fig, title, height=max(360, 32 * len(data) + 120))


def region_bar(regions: pd.DataFrame, by: str, title: str) -> go.Figure:
    data = regions.copy()
    data[by] = data[by].astype(str)
    data = data.sort_values("incidents")
    fig = px.bar(data, x="incidents", y=by, orientation="h", color_discrete_sequence=[PALETTE[4]],
                 hover_data={"share_pct": ":.1f"})
    fig.update_yaxes(type="category", title=by.replace("_", " ").title())
    return _style(fig, title, height=max(360, 24 * len(data) + 120))


def hour_weekday_heatmap(matrix: pd.DataFrame, title: str = "Incidents by weekday and hour") -> go.Figure:
    fig = px.imshow(matrix, aspect="auto", color_continuous_scale="Viridis",
                    labels=dict(x="Hour of day", y="Weekday", color="Incidents"))
    return _style(fig, title, height=380)


def crime_density_map(points: pd.DataFrame, title: str = "Incident density (sampled)") -> go.Figure:
    kwargs = dict(lat="latitude", lon="longitude", radius=6, zoom=9,
                  center=dict(lat=points["latitude"].mean(), lon=points["longitude"].mean()))
    if hasattr(px, "density_map"):
        fig = px.density_map(points, map_style="open-street-map", **kwargs)
    else:  # older Plotly
        fig = px.density_mapbox(points, mapbox_style="open-street-map", **kwargs)
    return _style(fig, title, height=560)


def forecast_chart(result: ForecastResult, title: str = "Actual vs predicted monthly incidents") -> go.Figure:
    fig = go.Figure()
    fig.add_scatter(x=result.train.index, y=result.train, name="Actual (training)",
                    line=dict(color=PALETTE[5]))
    fig.add_scatter(x=result.test.index, y=result.test, name="Actual (held-out test)",
                    line=dict(color=PALETTE[0], width=3))
    for i, (name, pred) in enumerate(result.predictions.items()):
        fig.add_scatter(x=pred.index, y=pred, name=f"Predicted: {name}",
                        line=dict(color=PALETTE[(i + 1) % len(PALETTE)], dash="dot"))
    fig.add_scatter(x=result.future.index, y=result.future,
                    name=f"Projection ({result.best_model})",
                    line=dict(color=PALETTE[3], dash="dash", width=3))
    fig.update_yaxes(title="Incidents per month")
    return _style(fig, title, height=480)
