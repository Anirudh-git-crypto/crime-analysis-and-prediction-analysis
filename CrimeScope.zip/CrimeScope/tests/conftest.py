"""Shared test fixtures.

NOTE: all data here is small SYNTHETIC test data written only to exercise the code.
It is never used by the dashboard or reported as crime statistics.
"""
import numpy as np
import pandas as pd
import pytest


@pytest.fixture
def raw_frame() -> pd.DataFrame:
    """Raw frame in the portal's column style, with deliberate defects."""
    return pd.DataFrame({
        "ID": [1, 2, 2, 3, 4, 5, 6],
        "Case Number": list("ABBCDEF"),
        "Date": ["01/05/2020 10:30:00 PM", "02/10/2020 01:00:00 AM", "02/10/2020 01:00:00 AM",
                 "not a date", "03/15/2021 12:00:00 PM", "04/01/2021 09:15:00 AM",
                 "05/20/2021 06:00:00 PM"],
        "Primary Type": ["THEFT", " theft ", " theft ", "BATTERY", "CRIM SEXUAL ASSAULT",
                         "CRIMINAL SEXUAL ASSAULT", None],
        "Arrest": ["true", "false", "false", "false", "true", "false", "false"],
        "District": [1, 2, 2, 3, 4, 5, 6],
        "Latitude": [41.88, 41.90, 41.90, 0.0, 41.75, 10.0, 41.80],
        "Longitude": [-87.63, -87.65, -87.65, 0.0, -87.60, -87.60, -87.70],
        "Unused Column": range(7),
    })


@pytest.fixture
def clean_frame(raw_frame):
    from src.data_cleaning import clean_crime_data
    df, _ = clean_crime_data(raw_frame, today=pd.Timestamp("2022-01-01"))
    return df


@pytest.fixture
def multi_year_frame() -> pd.DataFrame:
    """Synthetic cleaned-style frame covering 2019-2021 (2021 partial)."""
    rng = np.random.default_rng(0)
    dates = pd.date_range("2019-01-01", "2021-06-30", freq="D")
    rows = []
    for d in dates:
        for _ in range(3):
            rows.append((d, rng.choice(["THEFT", "BATTERY", "ASSAULT"], p=[0.5, 0.3, 0.2]),
                         int(rng.integers(1, 4))))
    df = pd.DataFrame(rows, columns=["date", "primary_type", "district"])
    df["year"], df["month"] = df["date"].dt.year, df["date"].dt.month
    df["month_start"] = df["date"].dt.to_period("M").dt.to_timestamp()
    df["hour"], df["day_of_week"] = df["date"].dt.hour, df["date"].dt.day_name()
    return df
