import math

import pytest

from src.data_analysis import (apply_filters, category_change, category_counts, headline_kpis,
                               hour_weekday_matrix, monthly_distribution, region_counts,
                               yearly_growth)
from src.utils import safe_pct_change


def test_safe_pct_change():
    assert safe_pct_change(150, 100) == 50.0
    assert safe_pct_change(50, 100) == -50.0
    assert math.isnan(safe_pct_change(10, 0))
    assert math.isnan(safe_pct_change(math.nan, 5))
    assert math.isnan(safe_pct_change(5, None))


def test_category_counts_sum_to_total(multi_year_frame):
    counts = category_counts(multi_year_frame)
    assert counts["incidents"].sum() == len(multi_year_frame)
    assert counts["share_pct"].sum() == pytest.approx(100.0)


def test_yearly_growth_skips_partial_years(multi_year_frame):
    growth = yearly_growth(multi_year_frame).set_index("year")
    assert math.isnan(growth.loc[2019, "pct_change"])
    assert not math.isnan(growth.loc[2020, "pct_change"])
    assert math.isnan(growth.loc[2021, "pct_change"])  # 2021 is partial
    assert not growth.loc[2021, "is_complete"]


def test_category_change_handles_zero_baseline(multi_year_frame):
    df = multi_year_frame.copy()
    df.loc[(df["year"] == 2019) & (df["primary_type"] == "ASSAULT"), "primary_type"] = "THEFT"
    change = category_change(df, 2019, 2020).set_index("category")
    assert math.isnan(change.loc["ASSAULT", "pct_change"])
    assert change.loc["ASSAULT", "direction"] == "New (no baseline)"


def test_category_change_validates_years(multi_year_frame):
    with pytest.raises(ValueError):
        category_change(multi_year_frame, 2019, 2019)
    with pytest.raises(ValueError):
        category_change(multi_year_frame, 2019, 1990)


def test_region_counts_validates_column(multi_year_frame):
    assert region_counts(multi_year_frame, "district")["incidents"].sum() == len(multi_year_frame)
    with pytest.raises(ValueError):
        region_counts(multi_year_frame, "not_a_column")


def test_monthly_distribution_uses_complete_years(multi_year_frame):
    monthly = monthly_distribution(multi_year_frame)
    assert len(monthly) == 12
    assert monthly["incidents"].sum() == len(multi_year_frame[multi_year_frame["year"] < 2021])


def test_filters_and_kpis(multi_year_frame):
    filtered = apply_filters(multi_year_frame, years=(2020, 2020), categories=["THEFT"])
    assert set(filtered["year"]) == {2020} and set(filtered["primary_type"]) == {"THEFT"}
    assert headline_kpis(filtered.iloc[0:0])["total"] == 0
    kpis = headline_kpis(multi_year_frame)
    assert kpis["total"] == len(multi_year_frame) and kpis["yoy_years"] == (2019, 2020)


def test_hour_weekday_matrix_shape(multi_year_frame):
    assert hour_weekday_matrix(multi_year_frame).shape == (7, 24)
