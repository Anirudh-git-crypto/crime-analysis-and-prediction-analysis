import pandas as pd
import pytest

from src.data_cleaning import (DataValidationError, clean_crime_data, daily_count_outliers,
                               normalize_categories, parse_dates, standardize_columns,
                               validate_clean_data)

TODAY = pd.Timestamp("2022-01-01")


def test_standardize_columns():
    out = standardize_columns(pd.DataFrame(columns=["Primary Type", " Case Number ", "X-Coord"]))
    assert list(out.columns) == ["primary_type", "case_number", "x_coord"]


def test_parse_dates_handles_bad_values():
    parsed = parse_dates(pd.Series(["01/05/2020 10:30:00 PM", "garbage", None]))
    assert parsed.iloc[0] == pd.Timestamp("2020-01-05 22:30:00")
    assert parsed.iloc[1:].isna().all()


def test_normalize_categories_merges_aliases():
    out = normalize_categories(pd.Series([" theft ", "CRIM SEXUAL ASSAULT", "Non - Criminal"]))
    assert list(out) == ["THEFT", "CRIMINAL SEXUAL ASSAULT", "NON-CRIMINAL"]


def test_clean_removes_defects(raw_frame):
    df, report = clean_crime_data(raw_frame, today=TODAY)
    assert report["rows_raw"] == 7
    assert report["duplicates_removed"] == 1
    assert report["unparseable_dates"] == 1
    assert report["missing_category"] == 1
    assert report["rows_clean"] == len(df) == 4
    assert "unused_column" not in df.columns
    assert df["primary_type"].isin(["THEFT", "CRIMINAL SEXUAL ASSAULT"]).all()


def test_invalid_coordinates_are_nulled_not_dropped(raw_frame):
    df, report = clean_crime_data(raw_frame, today=TODAY)
    assert report["invalid_coordinates_nulled"] >= 1
    assert df["latitude"].dropna().between(41.6, 42.05).all()


def test_derived_time_features(clean_frame):
    assert {"year", "month", "month_start", "hour", "day_of_week", "season"} <= set(clean_frame.columns)
    assert (clean_frame["year"] == clean_frame["date"].dt.year).all()


def test_missing_required_columns_raises():
    with pytest.raises(DataValidationError):
        clean_crime_data(pd.DataFrame({"foo": [1]}))


def test_validation_fails_on_bad_frame(clean_frame):
    bad = clean_frame.copy()
    bad.loc[0, "year"] = 1900
    with pytest.raises(DataValidationError):
        validate_clean_data(bad)


def test_future_dates_dropped(raw_frame):
    raw_frame.loc[0, "Date"] = "01/01/2099 10:00:00 AM"
    _, report = clean_crime_data(raw_frame, today=TODAY)
    assert report["dropped_implausible_dates"] == 1


def test_daily_outliers_reported_not_removed(multi_year_frame):
    frame = multi_year_frame.copy()
    spike = pd.concat([frame[frame["date"] == frame["date"].iloc[0]]] * 200)
    flagged = daily_count_outliers(pd.concat([frame, spike]))
    assert len(flagged) >= 1
