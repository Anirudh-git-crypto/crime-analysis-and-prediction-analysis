import numpy as np
import pandas as pd
import pytest

from src.prediction import (BASELINE, MIN_MONTHS, build_training_matrix, evaluate_forecast,
                            monthly_series, recursive_forecast, regression_metrics,
                            seasonal_naive_forecast)


@pytest.fixture
def synthetic_series() -> pd.Series:
    """SYNTHETIC monthly series (trend + seasonality + noise) used only for testing."""
    rng = np.random.default_rng(1)
    idx = pd.date_range("2015-01-01", periods=84, freq="MS")
    t = np.arange(84)
    values = 1000 + 3 * t + 120 * np.sin(2 * np.pi * idx.month / 12) + rng.normal(0, 10, 84)
    return pd.Series(values, index=idx)


def test_regression_metrics_known_values():
    m = regression_metrics(pd.Series([100.0, 200.0]), pd.Series([110.0, 180.0]))
    assert m["MAE"] == pytest.approx(15.0)
    assert m["RMSE"] == pytest.approx(np.sqrt((100 + 400) / 2))
    assert m["MAPE_%"] == pytest.approx((0.1 + 0.1) / 2 * 100)


def test_mape_ignores_zero_actuals():
    assert regression_metrics(pd.Series([0.0, 100.0]), pd.Series([5.0, 90.0]))["MAPE_%"] == pytest.approx(10.0)


def test_chronological_split_no_leakage(synthetic_series):
    res = evaluate_forecast(synthetic_series, test_months=12, horizon=6)
    assert res.train.index.max() < res.test.index.min()
    assert len(res.train) + len(res.test) == len(synthetic_series)
    assert res.future.index.min() > synthetic_series.index.max()
    assert len(res.future) == 6


def test_test_predictions_do_not_use_test_actuals(synthetic_series):
    """Changing test-period actuals must not change test-period predictions."""
    altered = synthetic_series.copy()
    altered.iloc[-12:] += 5000
    a = evaluate_forecast(synthetic_series, test_months=12)
    b = evaluate_forecast(altered, test_months=12)
    for name in a.predictions:
        np.testing.assert_allclose(a.predictions[name].to_numpy(), b.predictions[name].to_numpy())


def test_baseline_and_metrics_table(synthetic_series):
    res = evaluate_forecast(synthetic_series)
    assert BASELINE in set(res.metrics["model"])
    assert {"MAE", "RMSE", "MAPE_%"} <= set(res.metrics.columns)
    assert (res.metrics["MAE"] >= 0).all()
    assert res.future.ge(0).all()


def test_seasonal_naive_repeats_last_year(synthetic_series):
    out = seasonal_naive_forecast(synthetic_series, 14)
    last = synthetic_series.to_numpy()[-12:]
    np.testing.assert_allclose(out.to_numpy()[:12], last)
    assert out.iloc[12] == last[0]


def test_short_series_raises(synthetic_series):
    with pytest.raises(ValueError, match="at least"):
        evaluate_forecast(synthetic_series.iloc[: MIN_MONTHS - 1])


def test_invalid_parameters_raise(synthetic_series):
    with pytest.raises(ValueError):
        evaluate_forecast(synthetic_series, test_months=1)
    with pytest.raises(ValueError):
        evaluate_forecast(synthetic_series, horizon=0)


def test_training_matrix_shape(synthetic_series):
    X, y = build_training_matrix(synthetic_series)
    assert X.shape == (len(synthetic_series) - 12, 7) and len(y) == len(X)


def test_monthly_series_drops_incomplete_last_month(multi_year_frame):
    series = monthly_series(multi_year_frame)
    assert series.index.max() == pd.Timestamp("2021-06-01")  # June is complete in fixture
    trimmed = multi_year_frame[multi_year_frame["date"] <= "2021-06-10"]
    assert monthly_series(trimmed).index.max() == pd.Timestamp("2021-05-01")


def test_monthly_series_unknown_category(multi_year_frame):
    with pytest.raises(ValueError):
        monthly_series(multi_year_frame, category="NOPE")
