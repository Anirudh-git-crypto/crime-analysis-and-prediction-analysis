"""
Crime Analysis & Prediction Dashboard
A Streamlit web application for analyzing and predicting crime patterns
"""

import streamlit as st
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import time
import warnings
warnings.filterwarnings('ignore')

# Set page configuration
st.set_page_config(
    page_title="Crime Analysis & Prediction",
    page_icon="🚔",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS - Official Government Law Enforcement Theme
st.markdown("""
<style>
    /* ===== Global Background ===== */
    .stApp {
        background: linear-gradient(160deg, #0B1220 0%, #0F1B30 55%, #0B1220 100%);
    }

    /* ===== Scrollbar ===== */
    ::-webkit-scrollbar {
        width: 10px;
        height: 10px;
    }
    ::-webkit-scrollbar-track {
        background: #0B1220;
    }
    ::-webkit-scrollbar-thumb {
        background: #1E3557;
        border-radius: 6px;
    }
    ::-webkit-scrollbar-thumb:hover {
        background: #2A4A7A;
    }

    /* ===== Main Header (Official Banner) ===== */
    .main-header {
        font-size: 2.3rem;
        font-weight: 800;
        text-align: center;
        padding: 1.6rem 1rem;
        background: linear-gradient(135deg, #0E1E3A 0%, #14294F 50%, #0E1E3A 100%);
        border: 2px solid #F5C542;
        border-radius: 12px;
        color: #FFFFFF;
        letter-spacing: 1px;
        margin-bottom: 2rem;
        box-shadow: 0 8px 30px rgba(0,0,0,0.5);
        position: relative;
    }
    .main-header::before {
        content: "★ ★ ★ ★ ★";
        display: block;
        font-size: 0.9rem;
        color: #F5C542;
        letter-spacing: 8px;
        margin-bottom: 0.4rem;
    }
    .main-header::after {
        content: "";
        display: block;
        width: 120px;
        height: 3px;
        background: linear-gradient(90deg, transparent, #F5C542, transparent);
        margin: 0.8rem auto 0;
    }

    /* ===== Sub Header ===== */
    .sub-header {
        font-size: 1.4rem;
        font-weight: 700;
        color: #F5C542;
        padding: 0.6rem 0;
        border-bottom: 2px solid #2A4A7A;
        margin-bottom: 1.2rem;
        letter-spacing: 0.5px;
        display: flex;
        align-items: center;
    }
    .sub-header::before {
        content: "▸";
        color: #F5C542;
        margin-right: 0.6rem;
        font-size: 1.2rem;
    }

    /* ===== Metric Cards (Official Glass Style) ===== */
    .metric-card {
        background: linear-gradient(145deg, #111B2E 0%, #0E1626 100%);
        padding: 1.2rem 1rem;
        border-radius: 12px;
        text-align: center;
        border: 1px solid #2A4A7A;
        box-shadow: 0 6px 20px rgba(0,0,0,0.4);
        transition: transform 0.2s ease, box-shadow 0.2s ease;
        position: relative;
        overflow: hidden;
    }
    .metric-card:hover {
        transform: translateY(-4px);
        box-shadow: 0 10px 30px rgba(0,0,0,0.6);
        border-color: #F5C542;
    }
    .metric-card::before {
        content: "";
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 3px;
        background: linear-gradient(90deg, #F5C542, #1E8E4E);
    }
    .metric-icon {
        font-size: 1.6rem;
        margin-bottom: 0.3rem;
    }
    .metric-value {
        font-size: 1.9rem;
        font-weight: 800;
        color: #FFFFFF;
        line-height: 1.2;
    }
    .metric-label {
        font-size: 0.85rem;
        color: #A9B7CE;
        letter-spacing: 0.5px;
        text-transform: uppercase;
        margin-top: 0.2rem;
    }

    /* ===== Buttons ===== */
    .stButton>button {
        background: linear-gradient(135deg, #1E3A5F 0%, #14294F 100%);
        color: #FFFFFF;
        border: 1px solid #F5C542;
        padding: 0.55rem 2rem;
        border-radius: 6px;
        font-weight: 700;
        letter-spacing: 0.5px;
        transition: all 0.2s ease;
    }
    .stButton>button:hover {
        background: linear-gradient(135deg, #F5C542 0%, #D9A92E 100%);
        color: #0B1220;
        border-color: #F5C542;
        transform: scale(1.02);
    }

    /* ===== Sidebar ===== */
    [data-testid="stSidebar"] {
        background: linear-gradient(180deg, #0E1E3A 0%, #0B1220 100%);
    }
    [data-testid="stSidebar"] .stMarkdown h1,
    [data-testid="stSidebar"] .stMarkdown h2,
    [data-testid="stSidebar"] .stMarkdown h3 {
        color: #F5C542;
    }
    .sidebar-emblem {
        text-align: center;
        padding: 0.5rem 0;
    }
    .sidebar-title {
        font-size: 1.3rem;
        font-weight: 800;
        color: #FFFFFF;
        text-align: center;
        letter-spacing: 1px;
    }
    .sidebar-subtitle {
        font-size: 0.8rem;
        color: #F5C542;
        text-align: center;
        letter-spacing: 3px;
        text-transform: uppercase;
        margin-bottom: 0.6rem;
    }
    .sidebar-divider {
        border-top: 2px solid #2A4A7A;
        margin: 0.8rem 0;
    }

    /* ===== Expander / Info / Warning ===== */
    .stExpander {
        border: 1px solid #2A4A7A !important;
        border-radius: 8px !important;
        background: #0E1626;
    }
    .stExpander:hover {
        border-color: #F5C542 !important;
    }
    .stAlert {
        border-radius: 8px;
    }

    /* ===== Tabs ===== */
    .stTabs [data-baseweb="tab-list"] {
        gap: 0.5rem;
        border-bottom: 2px solid #2A4A7A;
    }
    .stTabs [data-baseweb="tab"] {
        background: transparent;
        color: #A9B7CE;
        font-weight: 600;
        border-radius: 6px 6px 0 0;
        padding: 0.5rem 1rem;
    }
    .stTabs [aria-selected="true"] {
        background: #14294F;
        color: #F5C542 !important;
        border-bottom: 3px solid #F5C542;
    }

    /* ===== Selectbox / Inputs ===== */
    .stSelectbox div[data-baseweb="select"] > div {
        background-color: #111B2E;
        border-color: #2A4A7A;
        color: #FFFFFF;
    }

    /* ===== Loading Screen ===== */
    .loading-screen {
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        padding: 3rem 1rem 1rem 1rem;
        text-align: center;
        background: linear-gradient(160deg, #0B1220 0%, #0F1B30 55%, #0B1220 100%);
        border-radius: 12px;
        border: 2px solid #2A4A7A;
    }
    .loading-badge {
        font-size: 5rem;
        animation: pulse-badge 1.5s ease-in-out infinite;
    }
    .loading-title {
        font-size: 2.2rem;
        font-weight: 800;
        color: #FFFFFF;
        margin: 1rem 0 0.5rem 0;
        letter-spacing: 1px;
        text-shadow: 0 0 20px rgba(245,197,66,0.3);
    }
    .loading-subtitle {
        color: #A9B7CE;
        font-size: 1rem;
        margin-bottom: 0.5rem;
        letter-spacing: 2px;
        text-transform: uppercase;
    }
    .loader-ring {
        width: 80px;
        height: 80px;
        border: 6px solid #1E3557;
        border-top-color: #F5C542;
        border-radius: 50%;
        animation: spin 1s linear infinite;
        margin: 1.5rem auto;
    }
    @keyframes spin {
        0% { transform: rotate(0deg); }
        100% { transform: rotate(360deg); }
    }
    @keyframes pulse-badge {
        0%, 100% { transform: scale(1); opacity: 1; }
        50% { transform: scale(1.15); opacity: 0.8; }
    }
    .loading-step {
        font-size: 1.1rem;
        color: #F5C542;
        font-weight: 600;
        min-height: 2rem;
    }

    /* ===== Footer ===== */
    .footer {
        text-align: center;
        color: #A9B7CE;
        padding: 1.2rem;
        border-top: 2px solid #2A4A7A;
        margin-top: 1rem;
        font-size: 0.9rem;
        letter-spacing: 0.5px;
    }
</style>
""", unsafe_allow_html=True)

# Initialize session state
if "data_loaded" not in st.session_state:
    st.session_state.data_loaded = False
if "models_loaded" not in st.session_state:
    st.session_state.models_loaded = False
if "df" not in st.session_state:
    st.session_state.df = None
if "models" not in st.session_state:
    st.session_state.models = None

# ============================================
# DATA LOADING FUNCTIONS
# ============================================

@st.cache(allow_output_mutation=True, suppress_st_warning=True)
def load_data():
    """Load or generate crime data"""
    try:
        df = pd.read_csv("crime_data.csv")
    except FileNotFoundError:
        from crime_data_generator import generate_crime_data
        df = generate_crime_data()
        df.to_csv("crime_data.csv", index=False)
    return df

@st.cache(allow_output_mutation=True, suppress_st_warning=True)
def load_models():
    """Load or train ML models"""
    from crime_model import load_models as _load_models
    from crime_model import train_models
    models = _load_models()
    if models is None:
        df = load_data()
        models = train_models(df)
    return models

# ============================================
# LOADING SCREEN
# ============================================

def render_loading_screen():
    """Display an animated loading splash while data & models initialize"""
    splash = st.empty()
    with splash.container():
        st.markdown("""
        <div class="loading-screen">
            <div class="loading-badge">🚔</div>
            <div class="loader-ring"></div>
            <div class="loading-title">Crime Analysis & Prediction</div>
            <div class="loading-subtitle">Loading dashboard components...</div>
        </div>
        """, unsafe_allow_html=True)

        progress = st.progress(0)
        status = st.empty()

        try:
            # Stage 1: Load data
            status.info("📊 Loading crime data...")
            df = load_data()
            st.session_state.df = df
            st.session_state.data_loaded = True
            progress.progress(40)

            # Stage 2: Load / train ML models
            status.info("🤖 Preparing ML models...")
            models = load_models()
            st.session_state.models = models
            st.session_state.models_loaded = True
            progress.progress(85)

            status.success("✅ Dashboard ready!")
            progress.progress(100)
            time.sleep(0.8)
        except Exception as e:
            status.error(f"❌ Failed to load dashboard components: {e}")
            time.sleep(2)

    splash.empty()

# ============================================
# SIDEBAR
# ============================================

# ===== Official Sidebar Header =====
st.sidebar.markdown("""
<div class="sidebar-emblem">
    <img src="https://img.icons8.com/fluency/96/police-badge.png" width="80" />
</div>
<div class="sidebar-title">CRIME ANALYSIS</div>
<div class="sidebar-subtitle">National Crime Records Bureau</div>
<div class="sidebar-divider"></div>
""", unsafe_allow_html=True)

# Load data
if st.sidebar.button("📊 Load / Refresh Data"):
    with st.spinner("Loading crime data..."):
        st.session_state.df = load_data()
        st.session_state.data_loaded = True
        st.sidebar.success(f"✅ Data loaded: {len(st.session_state.df)} records")

# Load models
if st.sidebar.button("🤖 Load / Train Models"):
    with st.spinner("Training ML models..."):
        if st.session_state.df is None:
            st.session_state.df = load_data()
        st.session_state.models = load_models()
        st.session_state.models_loaded = True
        st.sidebar.success("✅ Models ready!")

# ===== Status Panel =====
st.sidebar.markdown("### 📡 System Status")
status_col1, status_col2 = st.sidebar.columns(2)
with status_col1:
    st.markdown("**Data:**")
with status_col2:
    if st.session_state.data_loaded and st.session_state.df is not None:
        st.success(f"✅ {len(st.session_state.df):,} records")
    else:
        st.warning("⏳ Loading...")

with status_col1:
    st.markdown("**Models:**")
with status_col2:
    if st.session_state.models_loaded and st.session_state.models is not None:
        st.success("✅ Ready")
    else:
        st.warning("⏳ Loading...")

st.sidebar.markdown('<div class="sidebar-divider"></div>', unsafe_allow_html=True)

# ===== About Panel =====
st.sidebar.markdown("### ℹ️ About This System")
st.sidebar.info(
    "Official crime analytics dashboard. Analyzes crime patterns across "
    "Indian cities with ML-based severity and solve-rate predictions."
)
st.sidebar.caption("Authorized personnel only. All data is for analytical and research purposes.")

# ============================================
# MAIN CONTENT
# ============================================

# Header
st.markdown('<div class="main-header">🚔 Crime Analysis & Prediction Dashboard</div>', unsafe_allow_html=True)

# Auto-load data & models on first run with an animated loading screen
if not st.session_state.data_loaded or not st.session_state.models_loaded:
    render_loading_screen()

# Safety check: if loading failed, show error and stop
if st.session_state.df is None or st.session_state.models is None:
    st.error("❌ Dashboard failed to initialize. Please check the error above and try refreshing the app.")
    st.stop()

df = st.session_state.df

# ============================================
# CITY SELECTOR
# ============================================

st.markdown('<div class="sub-header">📍 Select City</div>', unsafe_allow_html=True)

cities = sorted(df["City"].unique())
col1, col2 = st.columns([3, 1])

with col1:
    selected_city = st.selectbox(
        "Choose a city to analyze:",
        cities,
        index=cities.index("Mumbai") if "Mumbai" in cities else 0
    )

with col2:
    selected_year = st.selectbox(
        "Select Year:",
        ["All"] + sorted(df["Year"].unique().tolist()),
        index=0
    )

# Filter data
city_data = df[df["City"] == selected_city]
if selected_year != "All":
    city_data = city_data[city_data["Year"] == selected_year]

# ============================================
# KEY METRICS
# ============================================

st.markdown('<div class="sub-header">📊 Key Statistics</div>', unsafe_allow_html=True)

total_cases = int(city_data["Cases_Reported"].sum())
total_solved = int(city_data["Solved_Cases"].sum())
solve_rate = round((total_solved / total_cases) * 100, 1) if total_cases > 0 else 0
avg_severity = round(city_data["Severity_Score"].mean(), 1)
unique_crimes = city_data["Crime_Type"].nunique()
population = int(city_data["Population"].iloc[0])

col1, col2, col3, col4, col5 = st.columns(5)

with col1:
    st.markdown(f"""
    <div class="metric-card">
        <div class="metric-icon">📁</div>
        <div class="metric-value">{total_cases:,}</div>
        <div class="metric-label">Total Cases</div>
    </div>
    """, unsafe_allow_html=True)

with col2:
    st.markdown(f"""
    <div class="metric-card">
        <div class="metric-icon">✅</div>
        <div class="metric-value">{total_solved:,}</div>
        <div class="metric-label">Solved Cases</div>
    </div>
    """, unsafe_allow_html=True)

with col3:
    st.markdown(f"""
    <div class="metric-card">
        <div class="metric-icon">📈</div>
        <div class="metric-value">{solve_rate}%</div>
        <div class="metric-label">Solve Rate</div>
    </div>
    """, unsafe_allow_html=True)

with col4:
    st.markdown(f"""
    <div class="metric-card">
        <div class="metric-icon">⚠️</div>
        <div class="metric-value">{avg_severity}/10</div>
        <div class="metric-label">Avg Severity</div>
    </div>
    """, unsafe_allow_html=True)

with col5:
    st.markdown(f"""
    <div class="metric-card">
        <div class="metric-icon">🕵️</div>
        <div class="metric-value">{unique_crimes}</div>
        <div class="metric-label">Crime Types</div>
    </div>
    """, unsafe_allow_html=True)

# ============================================
# CRIME DATA TABLE
# ============================================

st.markdown('<div class="sub-header">📋 Crime Data</div>', unsafe_allow_html=True)

with st.expander("📄 View Raw Data", expanded=False):
    display_cols = ["Year", "Month", "Crime_Type", "Cases_Reported", "Solved_Cases", 
                    "Solve_Rate_Pct", "Area_Type", "Severity_Score"]
    st.dataframe(city_data[display_cols].style.background_gradient(cmap="Blues"))
    
    col1, col2 = st.columns(2)
    with col1:
        csv = city_data.to_csv(index=False).encode('utf-8')
        st.download_button(
            "📥 Download CSV",
            csv,
            f"{selected_city}_crime_data.csv",
            "text/csv",
            key='download-csv'
        )
    with col2:
        st.info(f"Showing {len(city_data)} records for {selected_city}")

# ============================================
# VISUALIZATIONS
# ============================================

st.markdown('<div class="sub-header">📈 Crime Visualizations</div>', unsafe_allow_html=True)

tab1, tab2, tab3, tab4 = st.tabs(["📊 Crime Distribution", "📈 Trends Over Time", "🔍 Crime Comparison", "🗺️ City Comparison"])

with tab1:
    col1, col2 = st.columns(2)
    
    with col1:
        # Crime type distribution - Pie Chart
        crime_dist = city_data.groupby("Crime_Type")["Cases_Reported"].sum().reset_index()
        crime_dist = crime_dist.sort_values("Cases_Reported", ascending=False)
        
        # Use go.Pie with plain Python lists to avoid numpy binary-array serialization
        # issues with Streamlit 1.12.0's bundled Plotly.js (which would render all
        # slices with equal percentages).
        fig = go.Figure()
        fig.add_trace(go.Pie(
            labels=list(crime_dist["Crime_Type"]),
            values=crime_dist["Cases_Reported"].astype(int).tolist(),
            title=f"Crime Distribution in {selected_city}",
            marker=dict(colors=px.colors.sequential.Viridis),
            hole=0.3,
            textposition='inside',
            textinfo='percent+label'
        ))
        st.plotly_chart(fig, use_container_width=True)
    
    with col2:
        # Crime type by Cases - Bar Chart
        fig = px.bar(
            crime_dist.head(10),
            x="Crime_Type",
            y="Cases_Reported",
            title=f"Top Crime Types in {selected_city}",
            color="Cases_Reported",
            color_continuous_scale="Viridis"
        )
        fig.update_layout(xaxis_tickangle=-45)
        st.plotly_chart(fig, use_container_width=True)
    
    # Area Type Distribution
    area_dist = city_data.groupby("Area_Type")["Cases_Reported"].sum().reset_index()
    fig = px.bar(
        area_dist,
        x="Area_Type",
        y="Cases_Reported",
        title=f"Crime Distribution by Area Type in {selected_city}",
        color="Area_Type",
        color_discrete_sequence=px.colors.qualitative.Set2
    )
    st.plotly_chart(fig, use_container_width=True)

with tab2:
    col1, col2 = st.columns(2)
    
    with col1:
        # Monthly crime trend
        monthly_crimes = city_data.groupby(["Year", "Month"])["Cases_Reported"].sum().reset_index()
        monthly_crimes["Date"] = pd.to_datetime(monthly_crimes["Year"].astype(str) + "-" + monthly_crimes["Month"].astype(str) + "-01")
        monthly_crimes = monthly_crimes.sort_values("Date")
        
        fig = px.line(
            monthly_crimes,
            x="Date",
            y="Cases_Reported",
            title=f"Monthly Crime Trend in {selected_city}",
            markers=True,
            line_shape="spline"
        )
        fig.update_layout(xaxis_title="Date", yaxis_title="Cases Reported")
        st.plotly_chart(fig, use_container_width=True)
    
    with col2:
        # Yearly comparison
        yearly_crimes = city_data.groupby("Year")["Cases_Reported"].sum().reset_index()
        
        fig = px.bar(
            yearly_crimes,
            x="Year",
            y="Cases_Reported",
            title=f"Yearly Crime Comparison in {selected_city}",
            color="Cases_Reported",
            color_continuous_scale="Reds",
            text_auto=True
        )
        fig.update_traces(texttemplate='%{text:,.0f}', textposition='outside')
        st.plotly_chart(fig, use_container_width=True)
    
    # Solve Rate Trend
    solve_trend = city_data.groupby(["Year", "Month"])["Solve_Rate_Pct"].mean().reset_index()
    solve_trend["Date"] = pd.to_datetime(solve_trend["Year"].astype(str) + "-" + solve_trend["Month"].astype(str) + "-01")
    solve_trend = solve_trend.sort_values("Date")
    
    fig = px.line(
        solve_trend,
        x="Date",
        y="Solve_Rate_Pct",
        title=f"Crime Solve Rate Trend in {selected_city}",
        markers=True,
        color_discrete_sequence=["green"]
    )
    fig.update_layout(xaxis_title="Date", yaxis_title="Solve Rate (%)")
    st.plotly_chart(fig, use_container_width=True)

with tab3:
    col1, col2 = st.columns(2)
    
    with col1:
        # Severity by crime type
        severity_by_crime = city_data.groupby("Crime_Type")["Severity_Score"].mean().reset_index()
        severity_by_crime = severity_by_crime.sort_values("Severity_Score", ascending=False)
        
        fig = px.bar(
            severity_by_crime,
            x="Crime_Type",
            y="Severity_Score",
            title=f"Average Severity by Crime Type in {selected_city}",
            color="Severity_Score",
            color_continuous_scale="RdYlGn_r"
        )
        fig.update_layout(xaxis_tickangle=-45)
        st.plotly_chart(fig, use_container_width=True)
    
    with col2:
        # Solve rate by crime type
        solve_by_crime = city_data.groupby("Crime_Type")["Solve_Rate_Pct"].mean().reset_index()
        solve_by_crime = solve_by_crime.sort_values("Solve_Rate_Pct", ascending=False)
        
        fig = px.bar(
            solve_by_crime,
            x="Crime_Type",
            y="Solve_Rate_Pct",
            title=f"Solve Rate by Crime Type in {selected_city}",
            color="Solve_Rate_Pct",
            color_continuous_scale="Greens"
        )
        fig.update_layout(xaxis_tickangle=-45)
        st.plotly_chart(fig, use_container_width=True)
    
    # Heatmap - Crime by Month and Type
    heatmap_data = city_data.pivot_table(
        values="Cases_Reported",
        index="Crime_Type",
        columns="Month",
        aggfunc="sum",
        fill_value=0
    )
    
    fig = px.imshow(
        heatmap_data,
        title=f"Crime Heatmap - {selected_city} (Cases by Month & Crime Type)",
        color_continuous_scale="YlOrRd",
        aspect="auto",
        labels=dict(x="Month", y="Crime Type", color="Cases")
    )
    st.plotly_chart(fig, use_container_width=True)

with tab4:
    # Multi-city comparison
    selected_cities = st.multiselect(
        "Select cities to compare:",
        cities,
        default=[selected_city, "Delhi" if "Delhi" in cities and selected_city != "Delhi" else cities[1] if len(cities) > 1 else selected_city]
    )
    
    if selected_cities:
        comparison_data = df[df["City"].isin(selected_cities)]
        city_comparison = comparison_data.groupby("City")["Cases_Reported"].sum().reset_index()
        
        fig = px.bar(
            city_comparison,
            x="City",
            y="Cases_Reported",
            title="Total Crime Comparison Across Cities",
            color="City",
            color_discrete_sequence=px.colors.qualitative.Set2,
            text_auto=True
        )
        fig.update_traces(texttemplate='%{text:,.0f}', textposition='outside')
        st.plotly_chart(fig, use_container_width=True)
        
        # Crime type comparison
        crime_type_comp = comparison_data.groupby(["City", "Crime_Type"])["Cases_Reported"].sum().reset_index()
        
        fig = px.bar(
            crime_type_comp,
            x="Crime_Type",
            y="Cases_Reported",
            color="City",
            title="Crime Type Comparison Across Cities",
            barmode="group",
            color_discrete_sequence=px.colors.qualitative.Set2
        )
        fig.update_layout(xaxis_tickangle=-45)
        st.plotly_chart(fig, use_container_width=True)

# ============================================
# ML PREDICTION
# ============================================

st.markdown('<div class="sub-header">🤖 Crime Severity Prediction</div>', unsafe_allow_html=True)

if not st.session_state.models_loaded:
    st.warning("⚠️ Please click 'Load / Train Models' in the sidebar to enable predictions.")
else:
    st.info("Use the ML model to predict crime severity and solve rate for a given scenario.")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        pred_city = st.selectbox("City", cities, key="pred_city")
        pred_crime = st.selectbox("Crime Type", sorted(df["Crime_Type"].unique()), key="pred_crime")
    
    with col2:
        pred_year = st.number_input("Year", min_value=2025, max_value=2030, value=2025, step=1)
        pred_month = st.selectbox("Month", range(1, 13), format_func=lambda x: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", 
                                                                               "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"][x-1])
    
    with col3:
        pred_area = st.selectbox("Area Type", ["Urban", "Semi-Urban", "Rural"])
        # Get population for selected city
        city_pop = df[df["City"] == pred_city]["Population"].iloc[0]
        st.metric("Population", f"{city_pop:,}")
    
    # Season calculation
    if pred_month in [3, 4, 5]:
        pred_season = "Summer"
    elif pred_month in [6, 7, 8]:
        pred_season = "Autumn"
    elif pred_month in [9, 10, 11]:
        pred_season = "Winter"
    else:
        pred_season = "Spring"
    
    if st.button("🚀 Predict Crime Severity"):
        from crime_model import predict_crime_severity
        
        with st.spinner("Making prediction..."):
            severity, solve_category, confidence = predict_crime_severity(
                pred_city, pred_crime, pred_year, pred_month, 
                pred_season, pred_area, city_pop, st.session_state.models
            )
        
        if severity is not None:
            col1, col2, col3 = st.columns(3)
            
            with col1:
                severity_color = "red" if severity > 7 else ("orange" if severity > 5 else "green")
                st.markdown(f"""
                <div class="metric-card">
                    <div class="metric-value" style="color: {severity_color}">{severity}/10</div>
                    <div class="metric-label">Predicted Severity Score</div>
                </div>
                """, unsafe_allow_html=True)
            
            with col2:
                solve_color = "green" if solve_category in ["High", "Very High"] else "orange"
                st.markdown(f"""
                <div class="metric-card">
                    <div class="metric-value" style="color: {solve_color}">{solve_category}</div>
                    <div class="metric-label">Predicted Solve Rate</div>
                </div>
                """, unsafe_allow_html=True)
            
            with col3:
                conf_color = "green" if confidence > 70 else "orange"
                st.markdown(f"""
                <div class="metric-card">
                    <div class="metric-value" style="color: {conf_color}">{confidence}%</div>
                    <div class="metric-label">Prediction Confidence</div>
                </div>
                """, unsafe_allow_html=True)
            
            # Interpretation
            st.markdown("### 📝 Interpretation")
            if severity >= 7:
                st.error(f"⚠️ **High Severity Alert**: {pred_crime} in {pred_city} has a high predicted severity score ({severity}/10). Immediate attention recommended.")
            elif severity >= 5:
                st.warning(f"⚡ **Moderate Severity**: {pred_crime} in {pred_city} has a moderate predicted severity score ({severity}/10).")
            else:
                st.success(f"✅ **Low Severity**: {pred_crime} in {pred_city} has a low predicted severity score ({severity}/10).")
            
            if solve_category in ["Low", "Medium"]:
                st.info(f"💡 **Insight**: The predicted solve rate is **{solve_category}**. Consider allocating more resources to improve investigation outcomes.")
            else:
                st.info(f"💡 **Insight**: The predicted solve rate is **{solve_category}**. Current law enforcement strategies appear effective.")
        else:
            st.error("Model prediction failed. Please ensure models are loaded correctly.")
    
    # Feature Importance
    with st.expander("📊 View Model Feature Importance", expanded=False):
        from crime_model import get_feature_importance
        fi = get_feature_importance(st.session_state.models)
        if fi is not None:
            fig = px.bar(
                fi,
                x="Importance",
                y="Feature",
                orientation="h",
                title="Feature Importance in Severity Prediction Model",
                color="Importance",
                color_continuous_scale="Viridis"
            )
            st.plotly_chart(fig, use_container_width=True)
            st.caption("This shows which factors most influence the crime severity prediction.")

# ============================================
# FOOTER
# ============================================

st.markdown("""
<div class="footer">
    ★ ★ ★ ★ ★<br>
    🚔 NATIONAL CRIME ANALYSIS & PREDICTION SYSTEM 🚔<br>
    <span style="font-size:0.8rem; color:#6B7A93;">
        Official Dashboard | Built with Streamlit, Python & Machine Learning<br>
        Department of Crime Analytics & Research
    </span>
</div>
""", unsafe_allow_html=True)
