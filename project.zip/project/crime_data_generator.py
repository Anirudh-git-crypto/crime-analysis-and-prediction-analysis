"""
Crime Data Generator - Creates realistic crime dataset for Indian cities
"""

import pandas as pd
import numpy as np
import random
from datetime import datetime, timedelta

# Indian cities with population data (in lakhs)
CITIES = {
    "Mumbai": 12400,
    "Delhi": 1100,
    "Bangalore": 840,
    "Hyderabad": 680,
    "Ahmedabad": 560,
    "Chennai": 710,
    "Kolkata": 450,
    "Pune": 350,
    "Jaipur": 310,
    "Lucknow": 290,
    "Surat": 450,
    "Patna": 170,
    "Bhopal": 180,
    "Indore": 200,
    "Chandigarh": 110,
    "Kanpur": 280,
    "Nagpur": 250,
    "Visakhapatnam": 200,
    "Vadodara": 200,
    "Guwahati": 150,
    "Coimbatore": 160,
    "Madurai": 150,
    "Varanasi": 130,
    "Agra": 180,
    "Meerut": 150,
    "Nashik": 150,
    "Rajkot": 140,
    "Amritsar": 120,
    "Ludhiana": 160,
    "Raipur": 150,
    "Ranchi": 110,
    "Jodhpur": 130,
    "Thiruvananthapuram": 96,
    "Srinagar": 120,
    "Mysuru": 95,
}

# Crime types with base rates (per 100,000 population)
CRIME_TYPES = {
    "Theft": (120, 250),
    "Burglary": (80, 180),
    "Assault": (50, 120),
    "Robbery": (30, 90),
    "Murder": (2, 8),
    "Kidnapping": (5, 20),
    "Cyber Crime": (40, 150),
    "Fraud": (60, 130),
    "Drug Offenses": (20, 70),
    "Domestic Violence": (30, 80),
    "Vehicle Theft": (40, 100),
    "Hurt": (60, 140)
}

# Area types
AREA_TYPES = ["Urban", "Semi-Urban", "Rural"]

# Area type distribution by crime type (realistic probabilities)
# Urban crimes: property/tech crimes concentrated in cities
# Semi-Urban: mixed crimes
# Rural: crimes more common in rural areas
AREA_DISTRIBUTION = {
    "Theft": {"Urban": 0.55, "Semi-Urban": 0.30, "Rural": 0.15},
    "Burglary": {"Urban": 0.40, "Semi-Urban": 0.35, "Rural": 0.25},
    "Assault": {"Urban": 0.35, "Semi-Urban": 0.35, "Rural": 0.30},
    "Robbery": {"Urban": 0.50, "Semi-Urban": 0.30, "Rural": 0.20},
    "Murder": {"Urban": 0.25, "Semi-Urban": 0.30, "Rural": 0.45},
    "Kidnapping": {"Urban": 0.30, "Semi-Urban": 0.40, "Rural": 0.30},
    "Cyber Crime": {"Urban": 0.75, "Semi-Urban": 0.20, "Rural": 0.05},
    "Fraud": {"Urban": 0.60, "Semi-Urban": 0.25, "Rural": 0.15},
    "Drug Offenses": {"Urban": 0.45, "Semi-Urban": 0.30, "Rural": 0.25},
    "Domestic Violence": {"Urban": 0.30, "Semi-Urban": 0.35, "Rural": 0.35},
    "Vehicle Theft": {"Urban": 0.65, "Semi-Urban": 0.25, "Rural": 0.10},
    "Hurt": {"Urban": 0.40, "Semi-Urban": 0.35, "Rural": 0.25}
}

def generate_crime_data(seed=42):
    """
    Generate a realistic crime dataset for Indian cities
    """
    np.random.seed(seed)
    random.seed(seed)
    
    records = []
    
    for city, population_lakhs in CITIES.items():
        population = population_lakhs * 100000  # Convert to actual population
        
        # Generate data for years 2020-2024
        for year in range(2020, 2025):
            # Monthly variation
            for month in range(1, 13):
                # Seasonal effect: more crimes in summer (Apr-Jun) and winter (Oct-Dec)
                if month in [4, 5, 6]:
                    seasonal_factor = 1.3
                elif month in [10, 11, 12]:
                    seasonal_factor = 1.2
                elif month in [1, 2]:
                    seasonal_factor = 0.9
                else:
                    seasonal_factor = 1.0
                
                # Year-over-year trend (slight increase)
                trend_factor = 1.0 + (year - 2020) * 0.03
                
                for crime_type, (min_rate, max_rate) in CRIME_TYPES.items():
                    # Base rate per 100,000 population
                    base_rate = np.random.uniform(min_rate, max_rate)
                    
                    # Adjust for city size (larger cities have slightly higher rates)
                    city_factor = 1.0 + (population_lakhs / 2000)
                    
                    # Calculate cases
                    rate = base_rate * seasonal_factor * trend_factor * city_factor
                    cases = max(1, int(rate * (population / 100000) * 0.01))  # ~1% of rate
                    
                    # Solve rate varies by crime type
                    if crime_type in ["Murder", "Kidnapping"]:
                        solve_rate = np.random.uniform(0.6, 0.85)
                    elif crime_type in ["Cyber Crime", "Fraud"]:
                        solve_rate = np.random.uniform(0.3, 0.55)
                    else:
                        solve_rate = np.random.uniform(0.4, 0.75)
                    
                    solved_cases = int(cases * solve_rate)
                    
                    # Severity score (1-10)
                    severity_map = {
                        "Theft": (2, 4),
                        "Burglary": (3, 5),
                        "Assault": (5, 7),
                        "Robbery": (6, 8),
                        "Murder": (9, 10),
                        "Kidnapping": (8, 10),
                        "Cyber Crime": (4, 7),
                        "Fraud": (4, 6),
                        "Drug Offenses": (5, 8),
                        "Domestic Violence": (6, 8),
                        "Vehicle Theft": (3, 5),
                        "Hurt": (4, 6)
                    }
                    severity_min, severity_max = severity_map[crime_type]
                    severity_score = np.random.uniform(severity_min, severity_max)
                    
                    # Assign area type based on crime type distribution
                    area_probs = AREA_DISTRIBUTION[crime_type]
                    area_type = random.choices(
                        list(area_probs.keys()),
                        weights=list(area_probs.values()),
                        k=1
                    )[0]
                    
                    records.append({
                        "City": city,
                        "Year": year,
                        "Month": month,
                        "Season": "Summer" if month in [4, 5, 6] else ("Winter" if month in [10, 11, 12] else ("Spring" if month in [2, 3] else "Autumn")),
                        "Crime_Type": crime_type,
                        "Cases_Reported": cases,
                        "Solved_Cases": solved_cases,
                        "Solve_Rate_Pct": round(solve_rate * 100, 1),
                        "Population": population,
                        "Area_Type": area_type,
                        "Severity_Score": round(severity_score, 1),
                        "Crime_Rate_Per_100k": round((cases / population) * 100000, 2)
                    })
    
    df = pd.DataFrame(records)
    df = df.sort_values(["City", "Year", "Month", "Crime_Type"]).reset_index(drop=True)
    return df

def get_crime_summary(df, city):
    """Get summary statistics for a specific city"""
    city_data = df[df["City"] == city]
    
    summary = {
        "Total Cases": int(city_data["Cases_Reported"].sum()),
        "Total Solved": int(city_data["Solved_Cases"].sum()),
        "Overall Solve Rate": f"{round((city_data['Solved_Cases'].sum() / city_data['Cases_Reported'].sum()) * 100, 1)}%",
        "Most Common Crime": city_data.groupby("Crime_Type")["Cases_Reported"].sum().idxmax(),
        "Highest Severity Crime": city_data.groupby("Crime_Type")["Severity_Score"].mean().idxmax(),
        "Avg Monthly Cases": round(city_data["Cases_Reported"].mean(), 1),
        "Population": int(city_data["Population"].iloc[0])
    }
    return summary

if __name__ == "__main__":
    df = generate_crime_data()
    print(f"Generated {len(df)} records")
    print(f"Columns: {list(df.columns)}")
    print(f"Cities: {df['City'].unique()}")
    print(f"Crime Types: {df['Crime_Type'].unique()}")
    print(f"Years: {sorted(df['Year'].unique())}")
    print("\nSample data:")
    print(df.head())
    
    # Save to CSV
    df.to_csv("crime_data.csv", index=False)
    print("\nData saved to crime_data.csv")
