"""
Crime Prediction Model - Random Forest Classifier for Crime Severity Prediction
"""

import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix, r2_score, mean_absolute_error
import joblib
import os
import warnings
warnings.filterwarnings('ignore')

MODEL_PATH = "crime_model.pkl"
ENCODER_PATH = "label_encoders.pkl"

def prepare_data(df):
    """
    Prepare data for ML model training
    """
    # Create a copy
    data = df.copy()
    
    # Feature Engineering
    data["Month"] = data["Month"].astype(int)
    data["Year"] = data["Year"].astype(int)
    
    # Encode categorical variables
    label_encoders = {}
    
    for col in ["City", "Crime_Type", "Season", "Area_Type"]:
        le = LabelEncoder()
        data[col + "_Encoded"] = le.fit_transform(data[col])
        label_encoders[col] = le
    
    # Features for prediction
    feature_cols = [
        "City_Encoded", "Year", "Month", 
        "Crime_Type_Encoded", "Season_Encoded", 
        "Area_Type_Encoded", "Population"
    ]
    
    X = data[feature_cols]
    
    # Target 1: Severity Score (Regression)
    y_severity = data["Severity_Score"]
    
    # Target 2: Solve Rate Category (Classification)
    def categorize_solve_rate(rate):
        if rate < 30:
            return "Low"
        elif rate < 50:
            return "Medium"
        elif rate < 70:
            return "High"
        else:
            return "Very High"
    
    y_solve_category = data["Solve_Rate_Pct"].apply(categorize_solve_rate)
    
    # Encode target
    solve_le = LabelEncoder()
    y_solve_encoded = solve_le.fit_transform(y_solve_category)
    label_encoders["Solve_Category"] = solve_le
    
    return X, y_severity, y_solve_encoded, feature_cols, label_encoders

def train_models(df):
    """
    Train Random Forest models for severity prediction and solve rate classification
    """
    print("Preparing data for training...")
    X, y_severity, y_solve, feature_cols, label_encoders = prepare_data(df)
    
    # Split data
    X_train, X_test, y_sev_train, y_sev_test, y_sol_train, y_sol_test = train_test_split(
        X, y_severity, y_solve, test_size=0.2, random_state=42
    )
    
    print(f"Training samples: {len(X_train)}, Test samples: {len(X_test)}")
    
    # Scale features
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)
    
    # Model 1: Severity Score Regressor
    print("\nTraining Severity Score Regressor...")
    severity_model = RandomForestRegressor(
        n_estimators=100,
        max_depth=15,
        random_state=42,
        n_jobs=-1
    )
    severity_model.fit(X_train_scaled, y_sev_train)
    
    y_sev_pred = severity_model.predict(X_test_scaled)
    sev_r2 = r2_score(y_sev_test, y_sev_pred)
    sev_mae = mean_absolute_error(y_sev_test, y_sev_pred)
    
    print(f"Severity Model - R² Score: {sev_r2:.4f}")
    print(f"Severity Model - MAE: {sev_mae:.4f}")
    
    # Model 2: Solve Rate Category Classifier
    print("\nTraining Solve Rate Classifier...")
    solve_model = RandomForestClassifier(
        n_estimators=100,
        max_depth=12,
        random_state=42,
        n_jobs=-1
    )
    solve_model.fit(X_train_scaled, y_sol_train)
    
    y_sol_pred = solve_model.predict(X_test_scaled)
    sol_accuracy = accuracy_score(y_sol_test, y_sol_pred)
    
    print(f"Solve Rate Classifier - Accuracy: {sol_accuracy:.4f}")
    print("\nClassification Report:")
    print(classification_report(y_sol_test, y_sol_pred, 
                                target_names=label_encoders["Solve_Category"].classes_))
    
    # Save models
    models = {
        "severity_model": severity_model,
        "solve_model": solve_model,
        "scaler": scaler,
        "feature_cols": feature_cols,
        "label_encoders": label_encoders
    }
    
    joblib.dump(models, MODEL_PATH)
    print(f"\nModels saved to {MODEL_PATH}")
    
    return models

def load_models():
    """Load trained models"""
    if os.path.exists(MODEL_PATH):
        return joblib.load(MODEL_PATH)
    return None

def predict_crime_severity(city, crime_type, year, month, season, area_type, population, models):
    """
    Predict crime severity and solve rate for given parameters
    """
    if models is None:
        return None, None
    
    # Create input dataframe
    input_data = pd.DataFrame([{
        "City": city,
        "Year": year,
        "Month": month,
        "Crime_Type": crime_type,
        "Season": season,
        "Area_Type": area_type,
        "Population": population
    }])
    
    # Encode categorical variables
    le = models["label_encoders"]
    feature_cols = models["feature_cols"]
    
    for col in ["City", "Crime_Type", "Season", "Area_Type"]:
        try:
            input_data[col + "_Encoded"] = le[col].transform(input_data[col])
        except ValueError:
            # If unseen category, use most common
            input_data[col + "_Encoded"] = 0
    
    # Prepare features
    X_pred = input_data[feature_cols]
    
    # Scale
    X_pred_scaled = models["scaler"].transform(X_pred)
    
    # Predict severity
    severity_pred = models["severity_model"].predict(X_pred_scaled)[0]
    
    # Predict solve category
    solve_pred_encoded = models["solve_model"].predict(X_pred_scaled)[0]
    solve_category = le["Solve_Category"].inverse_transform([solve_pred_encoded])[0]
    
    # Get prediction probabilities
    solve_probs = models["solve_model"].predict_proba(X_pred_scaled)[0]
    confidence = max(solve_probs) * 100
    
    return round(severity_pred, 1), solve_category, round(confidence, 1)

def get_feature_importance(models):
    """Get feature importance from the severity model"""
    if models is None:
        return None
    
    importance = models["severity_model"].feature_importances_
    features = models["feature_cols"]
    
    # Clean feature names
    clean_names = [f.replace("_Encoded", "") for f in features]
    
    return pd.DataFrame({
        "Feature": clean_names,
        "Importance": importance
    }).sort_values("Importance", ascending=False)

if __name__ == "__main__":
    # Generate data and train models
    from crime_data_generator import generate_crime_data
    
    print("=" * 60)
    print("CRIME PREDICTION MODEL TRAINING")
    print("=" * 60)
    
    print("\nGenerating crime data...")
    df = generate_crime_data()
    print(f"Generated {len(df)} records")
    
    print("\nTraining models...")
    models = train_models(df)
    
    print("\n" + "=" * 60)
    print("Feature Importance:")
    print("=" * 60)
    fi = get_feature_importance(models)
    if fi is not None:
        print(fi.to_string(index=False))
    
    print("\n" + "=" * 60)
    print("Sample Prediction:")
    print("=" * 60)
    severity, solve_cat, conf = predict_crime_severity(
        "Mumbai", "Theft", 2024, 6, "Summer", "Urban", 12400000, models
    )
    print(f"City: Mumbai, Crime: Theft, Month: June 2024")
    print(f"Predicted Severity Score: {severity}/10")
    print(f"Predicted Solve Rate Category: {solve_cat}")
    print(f"Confidence: {conf}%")
