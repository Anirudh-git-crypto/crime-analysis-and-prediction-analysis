"""
Generate a PowerPoint Presentation and Project Report for the
Crime Analysis & Prediction Dashboard project.
"""

import pandas as pd
import numpy as np
from datetime import datetime

# ============================================================
# 1. Load data and compute statistics
# ============================================================
df = pd.read_csv("crime_data.csv")

n_cities = df["City"].nunique()
n_records = len(df)
n_crime_types = df["Crime_Type"].nunique()
years = sorted(df["Year"].unique())
n_years = len(years)
total_cases = int(df["Cases_Reported"].sum())
total_solved = int(df["Solved_Cases"].sum())
overall_solve_rate = round((total_solved / total_cases) * 100, 1)
avg_severity = round(df["Severity_Score"].mean(), 1)

# City with highest crime
city_cases = df.groupby("City")["Cases_Reported"].sum().sort_values(ascending=False)
top_city = city_cases.index[0]
top_city_cases = int(city_cases.iloc[0])

# Most common crime
crime_cases = df.groupby("Crime_Type")["Cases_Reported"].sum().sort_values(ascending=False)
top_crime = crime_cases.index[0]
top_crime_cases = int(crime_cases.iloc[0])

# Feature importance (from earlier training output)
feature_importance = [
    ("Crime_Type", 0.937),
    ("Month", 0.015),
    ("City", 0.014),
    ("Year", 0.012),
    ("Population", 0.011),
    ("Area_Type", 0.007),
    ("Season", 0.004),
]

model_metrics = {
    "severity_r2": 0.8927,
    "severity_mae": 0.5419,
    "solve_accuracy": 0.6026,
}

cities_list = ", ".join(sorted(df["City"].unique()))

print(f"Loaded {n_records} records | {n_cities} cities | {n_crime_types} crime types")

# ============================================================
# 2. PowerPoint Presentation
# ============================================================
from pptx import Presentation
from pptx.util import Inches, Pt, Emu
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR

# Colors
DARK_BLUE = RGBColor(0x1E, 0x3A, 0x5F)
ACCENT_BLUE = RGBColor(0x66, 0x7E, 0xEA)
PURPLE = RGBColor(0x76, 0x4B, 0xA2)
WHITE = RGBColor(0xFF, 0xFF, 0xFF)
LIGHT_GRAY = RGBColor(0xF0, 0xF2, 0xF6)
DARK_GRAY = RGBColor(0x33, 0x33, 0x33)
RED = RGBColor(0xC0, 0x39, 0x2B)

prs = Presentation()
prs.slide_width = Inches(13.333)
prs.slide_height = Inches(7.5)

BLANK = prs.slide_layouts[6]  # blank layout


def add_background(slide, color=LIGHT_GRAY):
    """Set slide background color."""
    background = slide.background
    fill = background.fill
    fill.solid()
    fill.fore_color.rgb = color


def add_textbox(slide, left, top, width, height, text, font_size=18,
                color=DARK_GRAY, bold=False, alignment=PP_ALIGN.LEFT,
                font_name="Calibri"):
    """Add a text box to a slide."""
    txBox = slide.shapes.add_textbox(left, top, width, height)
    tf = txBox.text_frame
    tf.word_wrap = True
    p = tf.paragraphs[0]
    p.text = text
    p.font.size = Pt(font_size)
    p.font.color.rgb = color
    p.font.bold = bold
    p.font.name = font_name
    p.alignment = alignment
    return txBox


def add_bullets(slide, left, top, width, height, items, font_size=18,
                color=DARK_GRAY, spacing=Pt(10)):
    """Add a list of bullet points to a slide."""
    txBox = slide.shapes.add_textbox(left, top, width, height)
    tf = txBox.text_frame
    tf.word_wrap = True
    first = True
    for item in items:
        p = tf.paragraphs[0] if first else tf.add_paragraph()
        first = False
        p.text = item
        p.font.size = Pt(font_size)
        p.font.color.rgb = color
        p.font.name = "Calibri"
        p.space_after = spacing
        p.level = 0
    return txBox


def add_header_bar(slide, title):
    """Add a header band with the slide title."""
    bar = slide.shapes.add_shape(1, Inches(0), Inches(0), prs.slide_width, Inches(1.1))
    bar.fill.solid()
    bar.fill.fore_color.rgb = DARK_BLUE
    bar.line.fill.background()
    add_textbox(slide, Inches(0.6), Inches(0.15), Inches(12), Inches(0.8),
                title, font_size=32, color=WHITE, bold=True)


def add_footer(slide, page_num):
    """Add footer with page number."""
    add_textbox(slide, Inches(12.2), Inches(7.05), Inches(1), Inches(0.4),
                str(page_num), font_size=12, color=DARK_GRAY,
                alignment=PP_ALIGN.RIGHT)


# ---------- Slide 1: Title ----------
slide = prs.slides.add_slide(BLANK)
add_background(slide, DARK_BLUE)
add_textbox(slide, Inches(1), Inches(2.0), Inches(11.3), Inches(1.2),
            "Crime Analysis & Prediction Dashboard", font_size=48, color=WHITE,
            bold=True, alignment=PP_ALIGN.CENTER)
add_textbox(slide, Inches(1), Inches(3.4), Inches(11.3), Inches(0.8),
            "A Machine Learning Web Application", font_size=28, color=ACCENT_BLUE,
            alignment=PP_ALIGN.CENTER)
add_textbox(slide, Inches(1), Inches(4.4), Inches(11.3), Inches(0.8),
            "Select a City → View Crime Data → Get ML Predictions",
            font_size=20, color=WHITE, alignment=PP_ALIGN.CENTER)
add_textbox(slide, Inches(1), Inches(5.6), Inches(11.3), Inches(0.8),
            f"Built with Streamlit | Python | Scikit-Learn | Pandas",
            font_size=18, color=LIGHT_GRAY, alignment=PP_ALIGN.CENTER)

# ---------- Slide 2: Agenda ----------
slide = prs.slides.add_slide(BLANK)
add_background(slide)
add_header_bar(slide, "Agenda")
add_bullets(slide, Inches(1), Inches(1.6), Inches(11), Inches(5),
            [
                "1. Project Overview",
                "2. Objectives",
                "3. Dataset & Features",
                "4. System Architecture",
                "5. Machine Learning Model",
                "6. Dashboard Features",
                "7. Results & Evaluation",
                "8. Conclusion & Future Scope",
            ], font_size=24, spacing=Pt(14))
add_footer(slide, 2)

# ---------- Slide 3: Overview ----------
slide = prs.slides.add_slide(BLANK)
add_background(slide)
add_header_bar(slide, "Project Overview")
add_bullets(slide, Inches(0.8), Inches(1.5), Inches(11.8), Inches(5),
            [
                "A web-based dashboard to analyze and predict crime patterns across Indian cities.",
                "Users can select a city from a dropdown and view all crime data for that area.",
                "Provides key statistics, interactive visualizations, and ML-based predictions.",
                f"Covers {n_cities} Indian cities with {n_crime_types} crime types from {years[0]}–{years[-1]}.",
                f"Dataset contains {n_records:,} records and {total_cases:,} total reported cases.",
                "Uses a Random Forest model to predict crime severity (1–10) and solve-rate category.",
            ], font_size=20, spacing=Pt(12))
add_footer(slide, 3)

# ---------- Slide 4: Objectives ----------
slide = prs.slides.add_slide(BLANK)
add_background(slide)
add_header_bar(slide, "Objectives")
add_bullets(slide, Inches(0.8), Inches(1.5), Inches(11.8), Inches(5),
            [
                "To provide a centralized platform for viewing crime statistics by city.",
                "To analyze crime trends over time (monthly, yearly) for each city.",
                "To compare crime patterns across different cities.",
                "To predict crime severity using machine learning.",
                "To estimate the solve rate for different crime types.",
                "To help law enforcement and policymakers make data-driven decisions.",
            ], font_size=20, spacing=Pt(12))
add_footer(slide, 4)

# ---------- Slide 5: Dataset ----------
slide = prs.slides.add_slide(BLANK)
add_background(slide)
add_header_bar(slide, "Dataset & Features")
add_bullets(slide, Inches(0.8), Inches(1.4), Inches(11.8), Inches(2.2),
            [
                f"Cities: {n_cities} major Indian cities",
                f"Crime Types: {n_crime_types} (Theft, Burglary, Assault, Robbery, Murder, etc.)",
                f"Time Span: {years[0]} – {years[-1]} ({n_years} years, monthly granularity)",
                f"Total Records: {n_records:,}",
            ], font_size=18, spacing=Pt(6))

# Dataset columns
add_textbox(slide, Inches(0.8), Inches(3.6), Inches(11), Inches(0.6),
            "Key Columns:", font_size=18, color=ACCENT_BLUE, bold=True)
add_bullets(slide, Inches(1), Inches(4.1), Inches(11.5), Inches(3),
            [
                "City, Year, Month, Season, Area_Type",
                "Crime_Type, Cases_Reported, Solved_Cases, Solve_Rate_Pct",
                "Population, Severity_Score, Crime_Rate_Per_100k",
            ], font_size=16, spacing=Pt(4))
add_footer(slide, 5)

# ---------- Slide 6: Architecture ----------
slide = prs.slides.add_slide(BLANK)
add_background(slide)
add_header_bar(slide, "System Architecture")

# Flow boxes
flow_data = [
    ("Crime Data\nGenerator", DARK_BLUE),
    ("Dataset\n(crime_data.csv)", ACCENT_BLUE),
    ("ML Model\n(Random Forest)", PURPLE),
    ("Streamlit\nDashboard", RED),
]

box_w = Inches(2.4)
box_h = Inches(1.8)
gap = Inches(0.6)
start_x = Inches(1.0)
y = Inches(2.8)

for i, (label, color) in enumerate(flow_data):
    left = start_x + i * (box_w + gap)
    box = slide.shapes.add_shape(1, left, y, box_w, box_h)
    box.fill.solid()
    box.fill.fore_color.rgb = color
    box.line.fill.background()
    tf = box.text_frame
    tf.word_wrap = True
    tf.paragraphs[0].text = label
    tf.paragraphs[0].font.size = Pt(16)
    tf.paragraphs[0].font.color.rgb = WHITE
    tf.paragraphs[0].font.bold = True
    tf.paragraphs[0].alignment = PP_ALIGN.CENTER
    tf.vertical_anchor = MSO_ANCHOR.MIDDLE

    # Arrow
    if i < len(flow_data) - 1:
        arrow = slide.shapes.add_shape(5, left + box_w + Inches(0.1),
                                       y + Inches(0.6), gap - Inches(0.2), Inches(0.6))
        arrow.fill.solid()
        arrow.fill.fore_color.rgb = DARK_GRAY
        arrow.line.fill.background()

add_textbox(slide, Inches(1), Inches(5.2), Inches(11), Inches(1.5),
            "Flow: Synthetic crime data is generated → stored as CSV → used to train a "
            "Random Forest model → model is loaded into a Streamlit web dashboard for "
            "interactive city-based analysis and predictions.",
            font_size=16, color=DARK_GRAY)
add_footer(slide, 6)

# ---------- Slide 7: ML Model ----------
slide = prs.slides.add_slide(BLANK)
add_background(slide)
add_header_bar(slide, "Machine Learning Model")

add_textbox(slide, Inches(0.8), Inches(1.3), Inches(11), Inches(0.6),
            "Random Forest Ensemble Learning", font_size=20, color=ACCENT_BLUE, bold=True)

add_bullets(slide, Inches(0.8), Inches(1.9), Inches(11.8), Inches(3),
            [
                "Model 1: RandomForestRegressor → predicts Severity Score (1–10)",
                "Model 2: RandomForestClassifier → predicts Solve Rate Category (Low/Medium/High/Very High)",
                "Categorical features encoded using LabelEncoder; numerical features scaled with StandardScaler.",
                "Data split: 80% training / 20% testing.",
            ], font_size=17, spacing=Pt(8))

add_textbox(slide, Inches(0.8), Inches(4.5), Inches(11), Inches(0.6),
            "Feature Importance", font_size=18, color=ACCENT_BLUE, bold=True)
imp_text = "\n".join([f"• {name}: {val*100:.1f}%" for name, val in feature_importance])
add_textbox(slide, Inches(1), Inches(5.0), Inches(11), Inches(2),
            imp_text, font_size=15, color=DARK_GRAY)
add_footer(slide, 7)

# ---------- Slide 8: Dashboard Features ----------
slide = prs.slides.add_slide(BLANK)
add_background(slide)
add_header_bar(slide, "Dashboard Features")

add_bullets(slide, Inches(0.8), Inches(1.5), Inches(11.8), Inches(5.5),
            [
                "📍 City Selector – dropdown to choose any of the 35 cities",
                "📊 Key Statistics – total cases, solved cases, solve rate, avg severity",
                "📋 Crime Data Table – detailed record view + CSV download",
                "📈 4 Interactive Chart Tabs:",
                "     • Crime Distribution (pie, bar, area-type)",
                "     • Trends Over Time (monthly & yearly)",
                "     • Crime Comparison (severity, solve rate, heatmap)",
                "     • City Comparison (multi-city analysis)",
                "🤖 ML Prediction Panel – predict severity & solve rate for any scenario",
                "📊 Feature Importance – shows which factors drive severity",
            ], font_size=18, spacing=Pt(8))
add_footer(slide, 8)

# ---------- Slide 9: Results ----------
slide = prs.slides.add_slide(BLANK)
add_background(slide)
add_header_bar(slide, "Results & Evaluation")

add_textbox(slide, Inches(0.8), Inches(1.4), Inches(11), Inches(0.6),
            "Model Performance", font_size=20, color=ACCENT_BLUE, bold=True)

metrics = [
    f"Severity Model R² Score: {model_metrics['severity_r2']:.4f}",
    f"Severity Model MAE: {model_metrics['severity_mae']:.4f}",
    f"Solve Rate Classifier Accuracy: {model_metrics['solve_accuracy']:.2%}",
]
add_bullets(slide, Inches(0.8), Inches(2.0), Inches(11.8), Inches(1.8),
            metrics, font_size=18, spacing=Pt(8))

add_textbox(slide, Inches(0.8), Inches(3.9), Inches(11), Inches(0.6),
            "Data Insights", font_size=20, color=ACCENT_BLUE, bold=True)
add_bullets(slide, Inches(0.8), Inches(4.5), Inches(11.8), Inches(2.5),
            [
                f"Total reported cases across all cities: {total_cases:,}",
                f"Overall solve rate: {overall_solve_rate}%",
                f"Highest crime city: {top_city} ({top_city_cases:,} cases)",
                f"Most common crime: {top_crime} ({top_crime_cases:,} cases)",
                f"Average severity score: {avg_severity}/10",
            ], font_size=17, spacing=Pt(8))
add_footer(slide, 9)

# ---------- Slide 10: Conclusion ----------
slide = prs.slides.add_slide(BLANK)
add_background(slide)
add_header_bar(slide, "Conclusion & Future Scope")

add_textbox(slide, Inches(0.8), Inches(1.4), Inches(11), Inches(0.6),
            "Conclusion", font_size=20, color=ACCENT_BLUE, bold=True)
add_bullets(slide, Inches(0.8), Inches(2.0), Inches(11.8), Inches(2.2),
            [
                "Successfully built an interactive crime analysis dashboard.",
                "Random Forest model predicts severity with high accuracy (R² ≈ 0.89).",
                "Users can easily explore crime data for any selected city.",
                "ML predictions assist in proactive law-enforcement planning.",
            ], font_size=17, spacing=Pt(8))

add_textbox(slide, Inches(0.8), Inches(4.4), Inches(11), Inches(0.6),
            "Future Scope", font_size=20, color=ACCENT_BLUE, bold=True)
add_bullets(slide, Inches(0.8), Inches(5.0), Inches(11.8), Inches(2),
            [
                "Integrate real-world crime datasets from government sources.",
                "Add geospatial maps (crime hotspots) using real coordinates.",
                "Incorporate deep learning (LSTM) for time-series prediction.",
                "Add user authentication and role-based access.",
                "Expand to district/ward-level granularity.",
            ], font_size=17, spacing=Pt(8))
add_footer(slide, 10)

# ---------- Slide 11: Thank You ----------
slide = prs.slides.add_slide(BLANK)
add_background(slide, DARK_BLUE)
add_textbox(slide, Inches(1), Inches(2.8), Inches(11.3), Inches(1.2),
            "Thank You!", font_size=52, color=WHITE, bold=True,
            alignment=PP_ALIGN.CENTER)
add_textbox(slide, Inches(1), Inches(4.2), Inches(11.3), Inches(0.8),
            "Questions & Discussion", font_size=24, color=ACCENT_BLUE,
            alignment=PP_ALIGN.CENTER)

pptx_path = "Crime_Prediction_Presentation.pptx"
prs.save(pptx_path)
print(f"✅ PowerPoint saved: {pptx_path}")

# ============================================================
# 3. Project Report (Word Document)
# ============================================================
from docx import Document
from docx.shared import Pt as DocPt, Inches as DocInches, RGBColor as DocRGB
from docx.enum.text import WD_ALIGN_PARAGRAPH

doc = Document()

# Styles
style = doc.styles["Normal"]
style.font.name = "Calibri"
style.font.size = DocPt(11)

def add_heading(text, level=1):
    h = doc.add_heading(text, level=level)
    for run in h.runs:
        run.font.color.rgb = DocRGB(0x1E, 0x3A, 0x5F)
    return h

def add_para(text, bold=False):
    p = doc.add_paragraph()
    run = p.add_run(text)
    run.bold = bold
    return p

def add_bullet(text):
    doc.add_paragraph(text, style="List Bullet")

# ---------- Title Page ----------
for _ in range(4):
    doc.add_paragraph()

title = doc.add_paragraph()
title.alignment = WD_ALIGN_PARAGRAPH.CENTER
run = title.add_run("Crime Analysis & Prediction Dashboard")
run.bold = True
run.font.size = DocPt(28)
run.font.color.rgb = DocRGB(0x1E, 0x3A, 0x5F)

subtitle = doc.add_paragraph()
subtitle.alignment = WD_ALIGN_PARAGRAPH.CENTER
run = subtitle.add_run("Project Report")
run.font.size = DocPt(20)
run.font.color.rgb = DocRGB(0x66, 0x7E, 0xEA)

for _ in range(2):
    doc.add_paragraph()

for line in [
    "A Machine Learning Web Application",
    f"Streamlit | Python | Scikit-Learn | Pandas | Plotly",
    "",
    f"Prepared on: {datetime.now().strftime('%B %d, %Y')}",
]:
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = p.add_run(line)
    run.font.size = DocPt(14)

doc.add_page_break()

# ---------- Table of Contents ----------
add_heading("Table of Contents", level=1)
toc_items = [
    "1. Introduction",
    "2. Objectives",
    "3. Dataset Description",
    "4. System Architecture",
    "5. Machine Learning Model",
    "6. Dashboard Features",
    "7. Results and Evaluation",
    "8. Conclusion",
    "9. Future Scope",
    "10. How to Run the Project",
    "11. References / Technologies",
]
for item in toc_items:
    add_para(item)

doc.add_page_break()

# ---------- 1. Introduction ----------
add_heading("1. Introduction", level=1)
add_para(
    "Crime is a major concern for urban areas across the world. Understanding crime "
    "patterns — where, when, and what types of crimes occur — is essential for law "
    "enforcement agencies, urban planners, and policymakers. This project presents a "
    "web-based Crime Analysis and Prediction Dashboard that allows users to select a "
    "city and explore detailed crime statistics for that area."
)
add_para(
    "The application is built using Streamlit, a Python framework for building data "
    "applications, combined with machine learning models from Scikit-Learn. The system "
    "generates a realistic synthetic crime dataset for Indian cities, analyzes trends, "
    "and uses a Random Forest model to predict crime severity and solve rates."
)

# ---------- 2. Objectives ----------
add_heading("2. Objectives", level=1)
for obj in [
    "To provide a centralized platform for viewing crime statistics by city.",
    "To analyze crime trends over time (monthly and yearly).",
    "To compare crime patterns across different cities.",
    "To predict crime severity using machine learning.",
    "To estimate solve rates for different crime types.",
    "To support data-driven decision-making for law enforcement.",
]:
    add_bullet(obj)

# ---------- 3. Dataset Description ----------
add_heading("3. Dataset Description", level=1)
add_para(
    "Since real-world crime data is not openly available in a structured format, this "
    "project uses a synthetically generated dataset that models realistic crime patterns "
    "for Indian cities. The dataset includes seasonal variations, yearly trends, and "
    "city-size effects to simulate plausible crime statistics."
)
add_para(f"The dataset contains the following characteristics:", bold=True)
for item in [
    f"Cities: {n_cities} major Indian cities",
    f"Crime Types: {n_crime_types} crime categories",
    f"Time Span: {years[0]} to {years[-1]} (monthly granularity)",
    f"Total Records: {n_records:,}",
    f"Total Reported Cases: {total_cases:,}",
]:
    add_bullet(item)

add_para("Key Columns:", bold=True)
for col in [
    "City – Name of the city",
    "Year / Month / Season – Time information",
    "Crime_Type – Category of crime (Theft, Assault, Murder, etc.)",
    "Cases_Reported – Number of reported cases",
    "Solved_Cases – Number of solved cases",
    "Solve_Rate_Pct – Percentage of cases solved",
    "Population – Population of the city",
    "Area_Type – Urban, Semi-Urban, or Rural",
    "Severity_Score – Severity rating from 1 to 10",
    "Crime_Rate_Per_100k – Crime rate normalized per 100,000 population",
]:
    add_bullet(col)

# ---------- 4. System Architecture ----------
add_heading("4. System Architecture", level=1)
add_para(
    "The system follows a modular pipeline consisting of four main components:"
)
add_bullet("Crime Data Generator (crime_data_generator.py) – generates the synthetic dataset.")
add_bullet("Dataset Storage (crime_data.csv) – stores the generated data.")
add_bullet("ML Model Trainer (crime_model.py) – trains and saves the Random Forest models.")
add_bullet("Streamlit Dashboard (app.py) – interactive web interface for analysis and prediction.")
add_para(
    "The data generator creates records using base crime rates per 100,000 population, "
    "adjusted by seasonal factors, year-over-year trends, and city size. The trained model "
    "is serialized to crime_model.pkl using joblib and loaded by the dashboard."
)

# ---------- 5. Machine Learning Model ----------
add_heading("5. Machine Learning Model", level=1)
add_para(
    "Two Random Forest models are used for prediction:"
)
add_bullet("RandomForestRegressor – predicts the Severity Score (a continuous value from 1 to 10).")
add_bullet("RandomForestClassifier – predicts the Solve Rate Category (Low, Medium, High, Very High).")
add_para(
    "Categorical features (City, Crime_Type, Season, Area_Type) are encoded using "
    "LabelEncoder, and numerical features are scaled using StandardScaler. The data is "
    "split into 80% training and 20% testing sets."
)
add_para("Feature Importance (Severity Model):", bold=True)
for name, val in feature_importance:
    add_bullet(f"{name}: {val*100:.1f}%")

# ---------- 6. Dashboard Features ----------
add_heading("6. Dashboard Features", level=1)
for feat in [
    "City Selector – a dropdown to select from all available cities.",
    "Key Statistics – total cases, solved cases, solve rate, average severity, crime type count.",
    "Crime Data Table – a sortable, filterable table of all records for the selected city, with CSV download.",
    "Crime Distribution – pie chart, bar chart, and area-type distribution.",
    "Trends Over Time – monthly crime trend, yearly comparison, and solve-rate trend.",
    "Crime Comparison – severity by crime type, solve rate by crime type, and a month×crime heatmap.",
    "City Comparison – compare total cases and crime-type breakdown across multiple cities.",
    "ML Prediction Panel – inputs for city, crime type, year, month, and area type to predict severity and solve rate.",
    "Feature Importance Viewer – visualizes which factors most influence severity predictions.",
]:
    add_bullet(feat)

# ---------- 7. Results and Evaluation ----------
add_heading("7. Results and Evaluation", level=1)
add_para("Model Performance:", bold=True)
add_bullet(f"Severity Regressor R² Score: {model_metrics['severity_r2']:.4f}")
add_bullet(f"Severity Regressor Mean Absolute Error: {model_metrics['severity_mae']:.4f}")
add_bullet(f"Solve Rate Classifier Accuracy: {model_metrics['solve_accuracy']:.2%}")
add_para("Data Insights:", bold=True)
add_bullet(f"Total reported cases across all cities: {total_cases:,}")
add_bullet(f"Overall solve rate: {overall_solve_rate}%")
add_bullet(f"City with highest number of crimes: {top_city} ({top_crime_cases:,} cases)")
add_bullet(f"Most common crime type: {top_crime} ({top_crime_cases:,} cases)")
add_bullet(f"Average severity score: {avg_severity}/10")

# ---------- 8. Conclusion ----------
add_heading("8. Conclusion", level=1)
add_para(
    "The Crime Analysis and Prediction Dashboard successfully demonstrates the use of "
    "machine learning for crime analytics. The application allows users to select a city "
    "and instantly view comprehensive crime data, including trends, distributions, and "
    "ML-based predictions. The Random Forest model achieves a high R² score of "
    f"{model_metrics['severity_r2']:.2f} for severity prediction, confirming the "
    "reliability of the prediction pipeline. This project serves as a solid foundation "
    "for building real-world crime intelligence systems."
)

# ---------- 9. Future Scope ----------
add_heading("9. Future Scope", level=1)
for fut in [
    "Integrate real-world crime datasets from government and open-data sources.",
    "Add geospatial mapping to visualize crime hotspots on maps.",
    "Use deep learning models such as LSTM for time-series crime forecasting.",
    "Add user authentication and role-based access for different stakeholders.",
    "Expand the granularity from city level to district and ward level.",
    "Deploy the application to the cloud (e.g., Streamlit Cloud, AWS, or Azure).",
]:
    add_bullet(fut)

# ---------- 10. How to Run ----------
add_heading("10. How to Run the Project", level=1)
add_para("Step 1 – Install dependencies:", bold=True)
doc.add_paragraph("pip install -r requirements.txt", style="No Spacing")
doc.add_paragraph()
add_para("Step 2 – Generate the dataset (optional):", bold=True)
doc.add_paragraph("python crime_data_generator.py", style="No Spacing")
doc.add_paragraph()
add_para("Step 3 – Train the model (optional):", bold=True)
doc.add_paragraph("python crime_model.py", style="No Spacing")
doc.add_paragraph()
add_para("Step 4 – Launch the application:", bold=True)
doc.add_paragraph("streamlit run app.py", style="No Spacing")
doc.add_paragraph()
add_para("Then open the browser at http://localhost:8501 (or the port shown in the terminal).")
add_para("In the sidebar, click 'Load / Refresh Data' and then 'Load / Train Models' to enable all features.")

# ---------- 11. References ----------
add_heading("11. Technologies Used", level=1)
techs = [
    "Python 3.9 – programming language",
    "Streamlit 1.12 – web application framework",
    "Pandas – data manipulation and analysis",
    "NumPy – numerical computing",
    "Scikit-Learn – machine learning models",
    "Matplotlib & Seaborn – static visualizations",
    "Plotly – interactive visualizations",
    "Joblib – model serialization",
]
for t in techs:
    add_bullet(t)

docx_path = "Crime_Prediction_Project_Report.docx"
doc.save(docx_path)
print(f"✅ Word report saved: {docx_path}")

print("\n🎉 Both files generated successfully!")

