"""
Generate all charts needed for the comprehensive project report.
Saves figures as PNG images in a 'report_charts' folder.
"""

import pandas as pd
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns
import os

# Ensure output directory exists
OUT_DIR = "report_charts"
os.makedirs(OUT_DIR, exist_ok=True)

# Load data
df = pd.read_csv("crime_data.csv")

# Set style
plt.rcParams["figure.figsize"] = (10, 6)
plt.rcParams["figure.dpi"] = 150
plt.rcParams["font.size"] = 11
sns.set_palette("viridis")

print(f"Loaded {len(df)} records, {df['City'].nunique()} cities")

# ============================================================
# Chart 1: Total Cases by City (Top 15) - Bar Chart
# ============================================================
city_cases = df.groupby("City")["Cases_Reported"].sum().sort_values(ascending=False).head(15)
fig, ax = plt.subplots()
bars = ax.barh(city_cases.index[::-1], city_cases.values[::-1], color=sns.color_palette("viridis", 15))
ax.set_title("Top 15 Cities by Total Reported Crime Cases", fontsize=14, fontweight="bold")
ax.set_xlabel("Total Cases Reported")
ax.set_ylabel("City")
ax.tick_params(axis="x", labelsize=9)
for i, v in enumerate(city_cases.values[::-1]):
    ax.text(v + v*0.01, i, f"{int(v):,}", va="center", fontsize=8)
plt.tight_layout()
plt.savefig(f"{OUT_DIR}/chart1_city_cases.png")
plt.close()

# ============================================================
# Chart 2: Crime Type Distribution - Bar Chart
# ============================================================
crime_cases = df.groupby("Crime_Type")["Cases_Reported"].sum().sort_values(ascending=False)
fig, ax = plt.subplots()
bars = ax.bar(crime_cases.index, crime_cases.values, color=sns.color_palette("viridis", len(crime_cases)))
ax.set_title("Total Cases by Crime Type", fontsize=14, fontweight="bold")
ax.set_xlabel("Crime Type")
ax.set_ylabel("Total Cases Reported")
ax.tick_params(axis="x", rotation=45, labelsize=9)
for i, v in enumerate(crime_cases.values):
    ax.text(i, v + v*0.01, f"{int(v):,}", ha="center", fontsize=7)
plt.tight_layout()
plt.savefig(f"{OUT_DIR}/chart2_crime_types.png")
plt.close()

# ============================================================
# Chart 3: Monthly Trend (all cities) - Line Chart
# ============================================================
monthly = df.groupby(["Year", "Month"])["Cases_Reported"].sum().reset_index()
monthly["Date"] = pd.to_datetime(monthly["Year"].astype(str) + "-" + monthly["Month"].astype(str) + "-01")
monthly = monthly.sort_values("Date")
fig, ax = plt.subplots()
ax.plot(monthly["Date"], monthly["Cases_Reported"], marker="o", markersize=3, linewidth=1.5, color="#764ba2")
ax.set_title("Monthly Crime Trend Across All Cities (2020-2024)", fontsize=14, fontweight="bold")
ax.set_xlabel("Date")
ax.set_ylabel("Total Cases Reported")
ax.grid(True, alpha=0.3)
plt.tight_layout()
plt.savefig(f"{OUT_DIR}/chart3_monthly_trend.png")
plt.close()

# ============================================================
# Chart 4: Yearly Crime Trend - Bar Chart
# ============================================================
yearly = df.groupby("Year")["Cases_Reported"].sum().reset_index()
fig, ax = plt.subplots()
bars = ax.bar(yearly["Year"], yearly["Cases_Reported"], color=sns.color_palette("Reds_r", len(yearly)))
ax.set_title("Yearly Crime Trend (2020-2024)", fontsize=14, fontweight="bold")
ax.set_xlabel("Year")
ax.set_ylabel("Total Cases Reported")
for i, v in enumerate(yearly["Cases_Reported"]):
    ax.text(yearly["Year"][i], v + v*0.01, f"{int(v):,}", ha="center", fontsize=10)
plt.tight_layout()
plt.savefig(f"{OUT_DIR}/chart4_yearly_trend.png")
plt.close()

# ============================================================
# Chart 5: Severity Score Distribution - Histogram
# ============================================================
fig, ax = plt.subplots()
ax.hist(df["Severity_Score"], bins=20, color="#667eea", edgecolor="white", alpha=0.85)
ax.set_title("Distribution of Crime Severity Scores", fontsize=14, fontweight="bold")
ax.set_xlabel("Severity Score (1-10)")
ax.set_ylabel("Frequency")
ax.grid(True, alpha=0.3)
plt.tight_layout()
plt.savefig(f"{OUT_DIR}/chart5_severity_dist.png")
plt.close()

# ============================================================
# Chart 6: Average Severity by Crime Type - Bar Chart
# ============================================================
sev_by_crime = df.groupby("Crime_Type")["Severity_Score"].mean().sort_values(ascending=False)
fig, ax = plt.subplots()
bars = ax.bar(sev_by_crime.index, sev_by_crime.values, color=sns.color_palette("RdYlGn_r", len(sev_by_crime)))
ax.set_title("Average Severity Score by Crime Type", fontsize=14, fontweight="bold")
ax.set_xlabel("Crime Type")
ax.set_ylabel("Average Severity Score")
ax.tick_params(axis="x", rotation=45, labelsize=9)
for i, v in enumerate(sev_by_crime.values):
    ax.text(i, v + 0.05, f"{v:.1f}", ha="center", fontsize=9)
plt.tight_layout()
plt.savefig(f"{OUT_DIR}/chart6_severity_by_crime.png")
plt.close()

# ============================================================
# Chart 7: Solve Rate by Crime Type - Bar Chart
# ============================================================
solve_by_crime = df.groupby("Crime_Type")["Solve_Rate_Pct"].mean().sort_values(ascending=False)
fig, ax = plt.subplots()
bars = ax.bar(solve_by_crime.index, solve_by_crime.values, color=sns.color_palette("Greens", len(solve_by_crime)))
ax.set_title("Average Solve Rate by Crime Type", fontsize=14, fontweight="bold")
ax.set_xlabel("Crime Type")
ax.set_ylabel("Average Solve Rate (%)")
ax.tick_params(axis="x", rotation=45, labelsize=9)
ax.set_ylim(0, 80)
for i, v in enumerate(solve_by_crime.values):
    ax.text(i, v + 1, f"{v:.1f}%", ha="center", fontsize=9)
plt.tight_layout()
plt.savefig(f"{OUT_DIR}/chart7_solve_by_crime.png")
plt.close()

# ============================================================
# Chart 8: Crime by Area Type - Pie Chart
# ============================================================
area_dist = df.groupby("Area_Type")["Cases_Reported"].sum()
fig, ax = plt.subplots()
colors = ["#667eea", "#764ba2", "#f093fb"]
ax.pie(area_dist.values, labels=area_dist.index, autopct="%1.1f%%",
       colors=colors, startangle=90, explode=(0.02, 0.02, 0.02))
ax.set_title("Crime Distribution by Area Type", fontsize=14, fontweight="bold")
plt.tight_layout()
plt.savefig(f"{OUT_DIR}/chart8_area_type.png")
plt.close()

# ============================================================
# Chart 9: Seasonal Crime Pattern - Bar Chart
# ============================================================
seasonal = df.groupby("Season")["Cases_Reported"].sum()
season_order = ["Spring", "Summer", "Autumn", "Winter"]
seasonal = seasonal.reindex(season_order)
fig, ax = plt.subplots()
bars = ax.bar(seasonal.index, seasonal.values, color=sns.color_palette("coolwarm", 4))
ax.set_title("Crime by Season", fontsize=14, fontweight="bold")
ax.set_xlabel("Season")
ax.set_ylabel("Total Cases Reported")
for i, v in enumerate(seasonal.values):
    ax.text(i, v + v*0.01, f"{int(v):,}", ha="center", fontsize=10)
plt.tight_layout()
plt.savefig(f"{OUT_DIR}/chart9_seasonal.png")
plt.close()

# ============================================================
# Chart 10: Heatmap - Crime Type vs Month
# ============================================================
heatmap_data = df.pivot_table(values="Cases_Reported", index="Crime_Type",
                              columns="Month", aggfunc="sum", fill_value=0)
fig, ax = plt.subplots(figsize=(12, 8))
sns.heatmap(heatmap_data, cmap="YlOrRd", annot=True, fmt=".0f", linewidths=0.5, ax=ax)
ax.set_title("Crime Heatmap: Cases by Crime Type and Month", fontsize=14, fontweight="bold")
ax.set_xlabel("Month")
ax.set_ylabel("Crime Type")
plt.tight_layout()
plt.savefig(f"{OUT_DIR}/chart10_heatmap.png")
plt.close()

# ============================================================
# Chart 11: Solve Rate Distribution - Histogram
# ============================================================
fig, ax = plt.subplots()
ax.hist(df["Solve_Rate_Pct"], bins=20, color="#2ecc71", edgecolor="white", alpha=0.85)
ax.set_title("Distribution of Crime Solve Rates", fontsize=14, fontweight="bold")
ax.set_xlabel("Solve Rate (%)")
ax.set_ylabel("Frequency")
ax.grid(True, alpha=0.3)
plt.tight_layout()
plt.savefig(f"{OUT_DIR}/chart11_solve_rate_dist.png")
plt.close()

# ============================================================
# Chart 12: Feature Importance - Horizontal Bar
# ============================================================
features = ["Crime_Type", "Month", "City", "Year", "Population", "Area_Type", "Season"]
importance = [0.937, 0.015, 0.014, 0.012, 0.011, 0.007, 0.004]
fig, ax = plt.subplots()
bars = ax.barh(features[::-1], importance[::-1], color=sns.color_palette("viridis", len(features)))
ax.set_title("Feature Importance in Severity Prediction Model", fontsize=14, fontweight="bold")
ax.set_xlabel("Importance")
ax.set_ylabel("Feature")
for i, v in enumerate(importance[::-1]):
    ax.text(v + 0.005, i, f"{v*100:.1f}%", va="center", fontsize=10)
plt.tight_layout()
plt.savefig(f"{OUT_DIR}/chart12_feature_importance.png")
plt.close()

print("\n✅ All 12 charts generated in 'report_charts' folder:")
for f in sorted(os.listdir(OUT_DIR)):
    print(f"   - {f}")

